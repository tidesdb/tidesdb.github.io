# tpcc-mysql-4000wh

packaged 2026-10-09T14:39:10+02:00

## runs
  TidesDB sweep 4VU iter1: nopm=44772 status=ok
  TidesDB sweep 8VU iter1: nopm=84733 status=ok
  TidesDB sweep 16VU iter1: nopm=130498 status=ok
  TidesDB sweep 32VU iter1: nopm=159718 status=ok
  TidesDB sweep 64VU iter1: nopm=155310 status=ok
  TidesDB sweep 128VU iter1: nopm=150423 status=ok
  TidesDB sweep 256VU iter1: nopm=146148 status=ok
  TidesDB sweep 512VU iter1: nopm=144382 status=ok
  TidesDB sweep 1024VU iter1: nopm=140631 status=ok
  TidesDB peak 32VU iter1: nopm=159342 status=ok
  TidesDB peak 32VU iter2: nopm=159595 status=ok
  TidesDB peak 32VU iter3: nopm=159587 status=ok
  InnoDB sweep 4VU iter1: nopm=39361 status=ok
  InnoDB sweep 8VU iter1: nopm=73212 status=ok
  InnoDB sweep 16VU iter1: nopm=118964 status=ok
  InnoDB sweep 32VU iter1: nopm=131930 status=ok
  InnoDB sweep 64VU iter1: nopm=128265 status=ok
  InnoDB sweep 128VU iter1: nopm=127485 status=ok
  InnoDB sweep 256VU iter1: nopm=125173 status=ok
  InnoDB sweep 512VU iter1: nopm=126526 status=ok
  InnoDB sweep 1024VU iter1: nopm=122721 status=ok
  InnoDB peak 32VU iter1: nopm=125981 status=ok
  InnoDB peak 32VU iter2: nopm=126121 status=ok
  InnoDB peak 32VU iter3: nopm=127436 status=ok

## provenance
  recorded      2026-10-09T05:38:00+02:00
  mysqld        /data/mysql/bin/mysqld  Ver 26.7.0 for Linux on x86_64 (Source distribution)
  plugin        e71618046211ba10  2026-10-08 15:48:04
  libtidesdb    libtidesdb.so.10.1.1  248d145ec4bccd26
  tidesdb-lib   5da6a91bb0cfd30077594c332cfa028f202f8431 master
  tidesql-mysql 7d0b1698154c68524c7856e04a6baf5f001bca1e master
  hammerdb      6.0
  kernel        6.8.0-136-generic
  cpu           13th Gen Intel(R) Core(TM) i9-13900
  ram           126 GiB
  data device   /dev/nvme1n1p1

## sha256
  ae8b0a1cf4c8a4f3693291c9322dfd3ea4ea8e697ed6d2ff968afcc23843ee05  ./bench/bench-mysql.sh
  bc4acf37baf33210c153fdccfdb3c669db7d3cb01483af102db41be878790912  ./bench/extract.py
  056f9dd6af2533659708eea4b8d8a3c517171bde11010f743b989f6be7c62d19  ./bench/hdb_build_mysql.tcl
  17a30f1d4a2597a338aa61b9ad1e7c612bdb1e46f94826ec25a06ba5904f36bc  ./bench/hdb_run_mysql.tcl
  ce55fda892e7cde37b176975d45a22d7cb46c52b06f39118d3cdbd84fdcea8ba  ./bench/mysql-innodb.cnf
  c73b85c56f8252d7c79e50ebe95f6489669a3309bd08886164e5a4bc68e9bb69  ./bench/mysql-tidesdb.cnf
  1d7c650462c634f894ef3fd2f47a0a97dcafd59a89dbbea15491c91d90eaef7a  ./bench/plot.py
  399d5772f873021da6cba0e4ec8dc6fb96e64c3bdc106200c9d411b103ef7502  ./bench/preflight.sh
  e5b1bd9f6fc3ec44bb3dd4405cd29dabf8e94e9d993e0d848d30d3c2c89b905a  ./bench/reference-hammerdb-mysqlio.cnf
  1a58f6c66ba96a070d86176ccd3ee2e7f332f7dacc30fe60affbc345464ac44c  ./bench/sample.sh
  a51dd22dd54fbeea10e4c3da4451d77ae1d630f56fd6f505f66ffda8e0e91c36  ./build_times.csv
  f684a3f49074a5f39a5789d26cee441e3a01afea1d9edd96e753e2d0672417e3  ./figures/build_time.pdf
  da4f12db2589483d285272415e9ca4c725af596d99503ae662d08111d93b1900  ./figures/build_time.png
  51c22426450936e082727b4e5d1f282197ebd880967a502467bba45f15237b6c  ./figures/build_time.svg
  d817eb9117ea737d914bf510664b56694ebc2a66de0ac25ddf6acf851658bf24  ./figures/errors_vs_vu.pdf
  96ed4d0be12cadceb0d83a566fc21a74afd8fb89cecd93dffa3364b544b0af3e  ./figures/errors_vs_vu.png
  55f959bf7aacac5a1d9b2e9e82a368566a93c9cb64b4f476173f6305e98b4306  ./figures/errors_vs_vu.svg
  89e3546ccafbc141e7e1486a61c2f0a547c6a7ee38470fe89ab1162a05a58ce2  ./figures/neworder_p50_vs_vu.pdf
  98692ca1067ca7addf35a4ebabd2fc75e8629164a9036dfd979665ac391a754f  ./figures/neworder_p50_vs_vu.png
  f9ac05120049a92a884071b027453e0f979b570d46bac074b340f086e6afc172  ./figures/neworder_p50_vs_vu.svg
  90d1083d57fe64e739ac21b0eba410bfd5f77929f5e127ded1f94b6a2cdb08b4  ./figures/neworder_p99_vs_vu.pdf
  2844ee5f34200f04f196dba7a4873c9dd91266046586ceb9f4eb242a7d3d14d3  ./figures/neworder_p99_vs_vu.png
  b5a9575b22bf342e54a705184cf2c2a299fd762bb9ca2b39b46e9a9c1060bd68  ./figures/neworder_p99_vs_vu.svg
  715788d7be50274b9466ad1cbbaab13847ad338980f3bd1eb91c0011f93eda82  ./figures/nopm_vs_vu.pdf
  658262bfcca53e86295a421d869941c130457dcd66cc6cb3866c5ce01f5dbb32  ./figures/nopm_vs_vu.png
  0b47686450102b819dda4abd716a3d3f468a31125c3157a8d5505c550ad703d5  ./figures/nopm_vs_vu.svg
  86e4f85fa39a33dcaea735debd30ad5addc337abc7baecf528833b0776f1e57b  ./figures/peak_nopm.pdf
  aa2c00dec5f77437207a87e67f90381216294c6601e9aa04fe941c59f8217266  ./figures/peak_nopm.png
  f7d0647801a6cac0308ee24a364438711c30e023d0d040b56b8ca9b0ce9a8d21  ./figures/peak_nopm.svg
  88a5b546972fe27b543eb00cbd24c27a8e7a43c3afa314839e47606e2584c937  ./figures/throughput_over_time.pdf
  d609fbdb58d9a086f6b012df6a2b8d100d4bbd675e54044620c8ab4eb6e11c37  ./figures/throughput_over_time.png
  90396e30ffa0b6129d6232452586a17235b6054400321e55a4f23f78ee1cf49b  ./figures/throughput_over_time.svg
  a4f26778e71760cd6b1e7c8faea0689e285d3c76076840ebe27114fe750c08e9  ./figures/timeline_innodb.pdf
  d9426ead4f40eecd0e30edf9f0e2cf39063938af64b23b95ac2a25a34d6ddd50  ./figures/timeline_innodb.png
  ce73daee58c683862e7e52469212238fa11473a6b8e3d380def56cf44fe1a3e0  ./figures/timeline_innodb.svg
  83c6cc0afbaf1d7098bbba5e7857734eb2c308c36765155bdf4c79d5161dccfc  ./figures/timeline_tidesdb.pdf
  a8654c4713aec3ca58f8e4f24e008df7936d80f79e1936999a018d32d8e45ea2  ./figures/timeline_tidesdb.png
  2fbb7bf7d144aa9aeb045ed1b6b478e7a88fa62b1b4cf15f1d9ce973f73a8461  ./figures/timeline_tidesdb.svg
  3a55b42d13c03a61e6699a255687e407599f8f1fcc5542c03bd07583603511e3  ./figures/tpm_vs_vu.pdf
  03aef550069e38b1b49889969f9888e52ef2dac5fa3c7beebabf55225b874003  ./figures/tpm_vs_vu.png
  c4a14655c92850b2d218f70d6340840553643832a3b8bdf2b4c83befe3f97dc1  ./figures/tpm_vs_vu.svg
  68c4f24598527fe458c8e0c935cfe1570da94c58a6423ade85f32849fc09b791  ./logs/config-build-innodb.txt
  a5d3cdaffd8fc5232aa9ee3e34160bcb106a92d865d065cb104dfb05d4ba823b  ./logs/config-build-tidesdb.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-1024vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-128vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-16vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-256vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-32vu-peak-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-32vu-peak-2.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-32vu-peak-3.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-32vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-4vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-512vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-64vu-sweep-1.txt
  779d5c772545a418a6b712d96c25cfcc966459435de1f0eecdf463431c92981d  ./logs/config-run-innodb-8vu-sweep-1.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-1024vu-sweep-1.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-128vu-sweep-1.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-16vu-sweep-1.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-256vu-sweep-1.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-32vu-peak-1.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-32vu-peak-2.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-32vu-peak-3.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-32vu-sweep-1.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-4vu-sweep-1.txt
  0e0acea538c23f86a33dfda5baa1332a99ce307d43e19249f95bfca67767104f  ./logs/config-run-tidesdb-512vu-sweep-1.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-64vu-sweep-1.txt
  83b04c844db1404788fafc4beca0c73fe766c77f723ba8544aa77d5db8e3b4a7  ./logs/config-run-tidesdb-8vu-sweep-1.txt
  394bb512fdd0b401ff093af8a907281c471fb4e20002989a2a18970c13c641e6  ./logs/err-final.log
  b5cc874c9fd9c9a9c02dd27af3c965f51b4f7765da64adffd2b3a83cb90d009a  ./logs/err-innodb-1024vu-sweep-1.log
  7529f92c6519b2d3e647bbf5e06736be0bf9bcdf1761db0cbc16ba25332b0624  ./logs/err-innodb-128vu-sweep-1.log
  9b2979f94b924d5aa3d7e25babc97e12bbdf70ce450fef11a842e04c8a1026ae  ./logs/err-innodb-16vu-sweep-1.log
  04739bf0d9fa13ccee29033c8e2944c52afc67b572289bec83d01a08d9d1fb64  ./logs/err-innodb-256vu-sweep-1.log
  7b1d0ca9aa422eb6c64459b1be5cddd8d41001e1217770aed42d1375cdb09198  ./logs/err-innodb-32vu-peak-1.log
  0b42f3881a9dd2135c592db71c80d4c8cf7d0d031d760deff023b27c1f13186c  ./logs/err-innodb-32vu-peak-2.log
  84faaaf0e0d22933b9216ab7f569a335a9e3a564cd44dfe5dfac5c272f818aba  ./logs/err-innodb-32vu-peak-3.log
  123bd48da0d6f88ac3630956a0a249970897c6bef75ea450711e774202440fd1  ./logs/err-innodb-32vu-sweep-1.log
  f5c722bca58c1fb5357ab55c9b4d6bf95346bf00bc964f4f5e2bce53826e7c25  ./logs/err-innodb-4vu-sweep-1.log
  8bf45c7c958f343f3d5bcf4b9b7a964de5f5ae6b3f3f6931d373a22d620e948c  ./logs/err-innodb-512vu-sweep-1.log
  630bbbc1b7c9f6f2b2ad77c6a44c503143247b4b275ed17ddb7225943464eeca  ./logs/err-innodb-64vu-sweep-1.log
  49d995ff2fc095a2564f5729a748f6c7fe30c15471136947954606f18a8bd221  ./logs/err-innodb-8vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_1024vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_128vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_16vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_256vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_32vu_peak_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_32vu_peak_iter2.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_32vu_peak_iter3.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_32vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_4vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_512vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_64vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_innodb_8vu_sweep_iter1.txt
  8309ebde406081b28cee61e7da96256ac88e1f922ccec2a6e176df742694974f  ./logs/errors_tidesdb_1024vu_sweep_iter1.txt
  e0f88a9febd6daba1122e76b8dd4548744662b780f83992a529519301f8d8c2a  ./logs/errors_tidesdb_128vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_tidesdb_16vu_sweep_iter1.txt
  a7c44b9e3f5a628b65b16ae85428b2e1d18b3a3010ca61d091fdd908220d4547  ./logs/errors_tidesdb_256vu_sweep_iter1.txt
  fd2630118ae521ddf299206d4210013c4c1e1995dd9f1ba9ce54915a59fb16e7  ./logs/errors_tidesdb_32vu_peak_iter1.txt
  97406b878be8aabdacbfb9ce5f5817b67dbcb97908d6f472c55e96c9773510b2  ./logs/errors_tidesdb_32vu_peak_iter2.txt
  fd2630118ae521ddf299206d4210013c4c1e1995dd9f1ba9ce54915a59fb16e7  ./logs/errors_tidesdb_32vu_peak_iter3.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_tidesdb_32vu_sweep_iter1.txt
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/errors_tidesdb_4vu_sweep_iter1.txt
  878156a572248a1c6751e9c0578a50ff0d380509090777082dc3d276e729d531  ./logs/errors_tidesdb_512vu_sweep_iter1.txt
  c630bd5396b0d76b20a7d40b8132f6ae99d01d2998802b64042c28db8e80bae6  ./logs/errors_tidesdb_64vu_sweep_iter1.txt
  97406b878be8aabdacbfb9ce5f5817b67dbcb97908d6f472c55e96c9773510b2  ./logs/errors_tidesdb_8vu_sweep_iter1.txt
  04e268529064332847a0b4f9a7ccd0823a163c902f0a79d1d21b0f72d6ae2c6a  ./logs/err-tidesdb-1024vu-sweep-1.log
  1a183033e7be26dac50466c4ef73647740356ba86142955bdbf4cb0e19b42701  ./logs/err-tidesdb-128vu-sweep-1.log
  9ec706aaa726ca32e2250f905f03a27abb00bba3f663c00dfa775ffbcbc3daa3  ./logs/err-tidesdb-16vu-sweep-1.log
  ba1c214b4017732449d2359831259e1e0e6ac6c2e7ee14ace96f5b2af4509051  ./logs/err-tidesdb-256vu-sweep-1.log
  749a29b286182ff33e305347e3dd936c4109aed16d7f7c9151c62a7cb1b68218  ./logs/err-tidesdb-32vu-peak-1.log
  e37dae7f0a418c2cc3f2083733a37a7adcc594d51982b2e7e1e736195590667b  ./logs/err-tidesdb-32vu-peak-2.log
  ca3a5b39b536847758d751653e91a3aabc560527c3a05a5ff63edca1fcc7251a  ./logs/err-tidesdb-32vu-peak-3.log
  5077cb9b58de6fab279a2e931d5e9f38a949719650374307e998408126c18b62  ./logs/err-tidesdb-32vu-sweep-1.log
  afa33151cd192ab376749a49f094d619cff0c6cdf5e977b9b0fbfb54c9ef85d9  ./logs/err-tidesdb-4vu-sweep-1.log
  05ece7bc405aecc9bd6cd68d17b798d87692e5d20a24148e6a33372e149bd50b  ./logs/err-tidesdb-512vu-sweep-1.log
  f7b7b42a28dcb9c8a3850a0ba89a94bf94d6b33a573b0bf77ab18af60a793da5  ./logs/err-tidesdb-64vu-sweep-1.log
  8b30d2819ec81ea21615e826bdc3571b6ea6f975e9ede34215d5db3f4fc121f9  ./logs/err-tidesdb-8vu-sweep-1.log
  a7d928d9bd48031a84cea81bc28180a692f577a885d2e7d4af5a910f1fc25115  ./logs/hdb-build-innodb.log
  af4506ef4a7d8f479311b22eca3d707b37c52a38386488b2b5548e11e223733f  ./logs/hdb-build-tidesdb.log
  36378f078f17456b68a1b071cc3e36e1830e24c3bf85c5c17c60df9ab662675c  ./logs/hdb-innodb-1024vu-sweep-1.log
  8267fadd0aceb7e58082c247c6029c1240f37ea876d9f12047b266a9de4f86ea  ./logs/hdb-innodb-128vu-sweep-1.log
  1ca7ebbc128b5a30502fbb088c07f3672f6046131b4fb393bce30b8da8bb0d3a  ./logs/hdb-innodb-16vu-sweep-1.log
  335848b8634ca98bfd5332a5438fa7ba676dde527e490eac8de48bef9b171fe5  ./logs/hdb-innodb-256vu-sweep-1.log
  2fa9515a991b2c20992f013a5c8524724ec76e5a95166d62fa4b6d44c0a54b76  ./logs/hdb-innodb-32vu-peak-1.log
  3ac6eafd3947089a531aa493006e1440d45359be1c2ab2cecd0ad5479bfd1fb9  ./logs/hdb-innodb-32vu-peak-2.log
  54863270b94ba402c449afbce3440a41fb70b6e044ada148fe68b6319e5483d8  ./logs/hdb-innodb-32vu-peak-3.log
  e019e66fdf90993c1be48ea34546fbd1f4b8dc5e3f5d353f5699ce5320075ec9  ./logs/hdb-innodb-32vu-sweep-1.log
  c631c1bd11514e9642560ab1ff57ba84a879649ff5acc3d2a207459878a8abe9  ./logs/hdb-innodb-4vu-sweep-1.log
  fb4c50a1eeb307dcdf3a5d8f21671040d98ece4b9b8da873a77bb3bc1de207a8  ./logs/hdb-innodb-512vu-sweep-1.log
  78cf680128e3c4a8d3d17b3881f3e1570b2a963d7bf998fbd8e26ccef375a83e  ./logs/hdb-innodb-64vu-sweep-1.log
  7b08b0d5bfe8987c37303bede2ae579c9c7211f8c5a8949684b3b6829ef07b69  ./logs/hdb-innodb-8vu-sweep-1.log
  1dc0969377accbba7883188ec2bea3b63768e736c404acb5fdbf8d243c393ff0  ./logs/hdb-tidesdb-1024vu-sweep-1.log
  e92209a8b515c60c0178f7a41b47858c8a2f752f8966a8ed1e6e026b78160333  ./logs/hdb-tidesdb-128vu-sweep-1.log
  bb73ace3f58def39e07a5217525c29c2f88af8003e789729a0837a2a36be2372  ./logs/hdb-tidesdb-16vu-sweep-1.log
  7c0029099a766c29635773bdb8b5f8e2c51b3b6a1cd674df2e0bc0bf7639e48e  ./logs/hdb-tidesdb-256vu-sweep-1.log
  3c4ec0c3d2f18ef39c97fa8a066342a67088747f840deca3aeeb2e2703df70c1  ./logs/hdb-tidesdb-32vu-peak-1.log
  1d478b800536aa8785c60f0873592324b7ecb118233991a7f8723e8f5b883678  ./logs/hdb-tidesdb-32vu-peak-2.log
  f8373d1146f2b4a96c0255aebe45e2806cce4c8af2ac73bee43f4debf23a2e38  ./logs/hdb-tidesdb-32vu-peak-3.log
  dded2cdd1eea1b219ffa92983546789494a3fddf2af891c03567bd6b6466ac76  ./logs/hdb-tidesdb-32vu-sweep-1.log
  fda266f4b19d8da8c2518792dd3079ee24da5994ff1734b0bdc9e36337bea028  ./logs/hdb-tidesdb-4vu-sweep-1.log
  2e854b50ac5ba8859dea67bf87b81a39df2ccf66c8b2d01acdb0f03727f5ed9d  ./logs/hdb-tidesdb-512vu-sweep-1.log
  56e811c86863840dece4a25df63cda1ce58ede3196b0d95d745d010ca6fb85b6  ./logs/hdb-tidesdb-64vu-sweep-1.log
  f5f5d44912700406831e678174fe2f399b7fa9ee5e643829819318f67fa71d98  ./logs/hdb-tidesdb-8vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/initialize.log
  b03a5ffcfd6dc51d13af96177e084d8e3d96ef255d4c236aec468dc5528693c7  ./logs/results-partial-before-maxconn-fix.csv
  a6f2e06f3e6de89d8e97e551a261c02d734768ca0cf1b12412fa0db6130ca713  ./logs/sample-innodb-1024vu-sweep-1.csv.gz
  3bf8bf92e04b54b1d9d219b9aefb4a1e994cf5507a4139f87468e10c59bd1874  ./logs/sample-innodb-128vu-sweep-1.csv.gz
  3d56d29ed5551d4b6865b3856e7cc3029c4178a9ea751691677886ede07c84de  ./logs/sample-innodb-16vu-sweep-1.csv.gz
  43a70783ae08a4400b484baf5950aa2622b470b7dc4f59030403deb8c390474e  ./logs/sample-innodb-256vu-sweep-1.csv.gz
  dc41dae34616330a46f9f4b4d9198426c1a52763af11e66363b9edcc039156ed  ./logs/sample-innodb-32vu-peak-1.csv.gz
  e8deb9027997f6c29b9208ba44e0e96850445f321a6f394f29409302ccec935b  ./logs/sample-innodb-32vu-peak-2.csv.gz
  2a5766352fa5bfdb1e4d8ee0cfec3703276c76166601f88a0ceade38d4be3283  ./logs/sample-innodb-32vu-peak-3.csv.gz
  6a44aa10a9e37614a242e208c121a0cc4b4be93d0f3b87c4c7eb68748454df21  ./logs/sample-innodb-32vu-sweep-1.csv.gz
  81c32572899ac70abd5ce9d03b0bf129c5502abf9b095fca167cbd30429e0ad2  ./logs/sample-innodb-4vu-sweep-1.csv.gz
  865b45049554783b8d845d0e162e6db66e4f535403e706b9a4764f8a2281a6e2  ./logs/sample-innodb-512vu-sweep-1.csv.gz
  efc0400b36b5476500222909e966b248735b35b502ee6d0f701c902c8ece8294  ./logs/sample-innodb-64vu-sweep-1.csv.gz
  4f49948982ae8b8e9f5d64126758a515c6611b6240a661087b8ffc38a79bb2ba  ./logs/sample-innodb-8vu-sweep-1.csv.gz
  259598419f8c9d00717d64c49abd62a0c728164d9dd8ab586a50651cc37e745f  ./logs/sample-tidesdb-1024vu-sweep-1.csv.gz
  363f7cb0510d52ccd2ceb2b731da21e55836a4dad8d00001eff9252f37df8315  ./logs/sample-tidesdb-128vu-sweep-1.csv.gz
  4e1ccba3e9c8a0d1906b136a87378d97590350c9ce3a366baf4c2b1369249b98  ./logs/sample-tidesdb-16vu-sweep-1.csv.gz
  7370b927ad33100a5dc0f9ee2b8837f5cab0f958a6ec4a5eb9aa42a258112c9a  ./logs/sample-tidesdb-256vu-sweep-1.csv.gz
  553d7d93ae92d4c1dcaf1bafdbde477ea09486296ffaee385cfb365b593cce57  ./logs/sample-tidesdb-32vu-peak-1.csv.gz
  1e496aeb631eac9784033abc8be1c6bf711db565c7f0c6cc776841635e0b93af  ./logs/sample-tidesdb-32vu-peak-2.csv.gz
  e8ea5f4e54747ea24dddaeee38e63298ac204814777aa20ea9c0de7ab90bc4f4  ./logs/sample-tidesdb-32vu-peak-3.csv.gz
  49400fd1d5531dd42f0b3424b88b77038f841ac4abfe4930f47c3ac835a4584a  ./logs/sample-tidesdb-32vu-sweep-1.csv.gz
  c9d3fd3aed9e3904e930e812f0295e9995f19cdbc738bc711ee4bdab9a9d1a9a  ./logs/sample-tidesdb-4vu-sweep-1.csv.gz
  bdf3100bdd6402778329ad0d0d2269681065d54f28d78c6831190558a323dfdb  ./logs/sample-tidesdb-512vu-sweep-1.csv.gz
  e6c54f2fd94b933c032b6609068097b4a24825d9dee8b516eafe5a13e1e9e86a  ./logs/sample-tidesdb-64vu-sweep-1.csv.gz
  d48a2860f5a59e08f86f4596edd9f33fda1c861b95de674772bcc1c8af4ac364  ./logs/sample-tidesdb-8vu-sweep-1.csv.gz
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-build-innodb.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-build-tidesdb.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-pristine.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-1024vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-128vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-16vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-256vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-32vu-peak-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-32vu-peak-2.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-32vu-peak-3.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-32vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-4vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-512vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-64vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-innodb-8vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-1024vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-128vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-16vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-256vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-32vu-peak-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-32vu-peak-2.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-32vu-peak-3.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-32vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-4vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-512vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-64vu-sweep-1.log
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ./logs/server-run-tidesdb-8vu-sweep-1.log
  0b672b5ef490a037bed47a290840e3593a8a3d906980b8ee5c5b995070481b79  ./logs/status-innodb-1024vu-sweep-1-after.txt
  26dd6cfc97a8ce18bb801cac020c0dee008cc245af629e68aed82ac4b2ec81c2  ./logs/status-innodb-1024vu-sweep-1-before.txt
  097c14456cbcd6aa7db0a9e297e13dc503d2e4716282166d5a212f03af2537ef  ./logs/status-innodb-128vu-sweep-1-after.txt
  ee63183269a5549ad2edf1107bc4dabf9c094f183e9b833d53594344444e57d7  ./logs/status-innodb-128vu-sweep-1-before.txt
  06addaa3f76ec50607410cd63f1fbf4fa38dd0f8b873b3fafbedb0be2727f290  ./logs/status-innodb-16vu-sweep-1-after.txt
  1f37c7705c0465537babd51e152bd95a05a8099a1eda020abf003970099f07c5  ./logs/status-innodb-16vu-sweep-1-before.txt
  b32c12f2f454faf2a2e4a98600825d674751c20561e3f0cd14e290b2b931a245  ./logs/status-innodb-256vu-sweep-1-after.txt
  8db37ab8172eab50546b1d50d79135969c3e6ced5c3c83766fb59e0c36d93d76  ./logs/status-innodb-256vu-sweep-1-before.txt
  5301f86107a6205125c1aa4ba5397f9f7604e4ce7b361e7fab0d5882bd694dea  ./logs/status-innodb-32vu-peak-1-after.txt
  6274b7b45cc8ff63eb9c35e83adb57037527822ea560b7c70dd38165512967e0  ./logs/status-innodb-32vu-peak-1-before.txt
  252e31395dc7a5be4a8aa25d662217b3c73af2877469c97da57f8222b043e81c  ./logs/status-innodb-32vu-peak-2-after.txt
  15f4be900d5f6b644e80d1e984d1f9a3145b18a987305b942223ee0398d63702  ./logs/status-innodb-32vu-peak-2-before.txt
  fc0864b538983e9286b95f77fb6930063d652efa9ff26859f1155ce67e46459e  ./logs/status-innodb-32vu-peak-3-after.txt
  ddf1dd490987fbfabba50c1971b36a740e5199a4fedf2a9c7c8db53ef124ec23  ./logs/status-innodb-32vu-peak-3-before.txt
  c5f634227300c594fc60f95dbd5bbeab0259e51fea32699fdbf33d3732f5e0bb  ./logs/status-innodb-32vu-sweep-1-after.txt
  8533633c2046d2c73c0277c6e233485e692728fd3b461947f7c9d30ab7dc06fd  ./logs/status-innodb-32vu-sweep-1-before.txt
  0fe5bf246cade8e709d8cbaef2c55b6c9e804ddf2b8ab99b82370c475b46e073  ./logs/status-innodb-4vu-sweep-1-after.txt
  09b66a5b8a9df1ec750669f7b83e9625e58f00f2acea1b64e5682606d801c6e4  ./logs/status-innodb-4vu-sweep-1-before.txt
  b5ce9c5eaa8d9b525bb07f2cb8b275993865e3cc0fc59597cc13e6e7a284211a  ./logs/status-innodb-512vu-sweep-1-after.txt
  4a89d05bbd9e395391330f3b39020f2a15b3e13e3a4635a6b57dc446e059c1ea  ./logs/status-innodb-512vu-sweep-1-before.txt
  a3d9e2db96576a9c63b639f1022f9c5b8a7ccebf32a7e1712e467585142081cc  ./logs/status-innodb-64vu-sweep-1-after.txt
  0b2010db3c2166102b93fb840e9df6ad1ab4ab4ea6eef7ec406765f73db1b375  ./logs/status-innodb-64vu-sweep-1-before.txt
  47813c37b1126af5b1acb6eb32e778a31fd903c4c8429d391ae481b2076aadd8  ./logs/status-innodb-8vu-sweep-1-after.txt
  d1411bd55e137919b0f8fa0291b04bb335ce10022a6d11be97a55ad251ff3366  ./logs/status-innodb-8vu-sweep-1-before.txt
  c9e3ee23b5128521617a71c7c6729bdaeb8a40dabb58d8996119efd09feaa816  ./logs/status-tidesdb-1024vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-1024vu-sweep-1-before.txt
  9e005cc9e6011b5a1629b38d4e9761eba13ff0e3435ded25af27ad21dfd5d2bd  ./logs/status-tidesdb-128vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-128vu-sweep-1-before.txt
  88e2e0b7ff7fb59efe4473154f77d5be2f07c8a8f22594370c2378f1b26ff95a  ./logs/status-tidesdb-16vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-16vu-sweep-1-before.txt
  2746c08c90515e616557dcb5633624f272aeb49704ada3fd976a9aaae8f053e2  ./logs/status-tidesdb-256vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-256vu-sweep-1-before.txt
  2fcaf43f1ff91259d948616ef33b014ce458977dde5bd0928d5f5a469eeef6ab  ./logs/status-tidesdb-32vu-peak-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-32vu-peak-1-before.txt
  95ca69407af36a1f2542e367e900e1a1a39873c91dc3bddbe5d96ea8f9809faa  ./logs/status-tidesdb-32vu-peak-2-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-32vu-peak-2-before.txt
  8a3be98a9e71ee900839a6471f37da164f32175c635e62d95c3803b563a5ee86  ./logs/status-tidesdb-32vu-peak-3-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-32vu-peak-3-before.txt
  bccd2b1f5bcd715d22b50dade3b417343f7bb91460e7583c98f3ebef88468c3d  ./logs/status-tidesdb-32vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-32vu-sweep-1-before.txt
  f3e16a6201a333dbb94127fd9f8c7cc129ded3c5795b906d9f307ed53bfedb1f  ./logs/status-tidesdb-4vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-4vu-sweep-1-before.txt
  7bbcfc079c41c6784e803c1603f364df0cf6a64142579bcc16399ed4428b4117  ./logs/status-tidesdb-512vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-512vu-sweep-1-before.txt
  019441358e820ca201bce540f9cc16961ebdad9a9c675cfbeb23c9347eb081ea  ./logs/status-tidesdb-64vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-64vu-sweep-1-before.txt
  21af1f7547e2fe88c5db59bef0a66a1be1d72933e563470c8e6862f38d410508  ./logs/status-tidesdb-8vu-sweep-1-after.txt
  ecdd18558d5b495facfab4b95f43f8a9a9c93bf01ee4dfba0244c5b3fc658009  ./logs/status-tidesdb-8vu-sweep-1-before.txt
  567b0591bc2e501f4793d46f9188cfba68eff28ddeb6b9070baee36166ac0bb1  ./logs/tables-innodb.txt
  6ca5064fe2af750d659c7f6a3e7c02fc4a51f0ec630883054f54f54d3ce6994a  ./logs/tables-tidesdb.txt
  d7139b7b926c7efe54c127bdfe9a71681c69f218e63aa3479e38958b31fad2d6  ./provenance.txt
  d575b70bb0b607e4a96dadcfc25129f2b0fb9684a7c5fbd3b255512fa9bd7c97  ./README.md
  e012c04c1ea7ea597ea3c60f597ccc63ee53e2580208cac8719b4fb6ad4b8181  ./results.csv
  4189b4893184a16b01b50b0d75327a1a9a90a853d65b4ffac927b12c0a726c95  ./run.json
  dc16b25af7ba5ed3af9776a48ecd473ba217a4f5b008dcfe48d7c33fd98bc9a7  ./space.csv
  cc7cabe4822810174ce153cfa630d0966245ffe3853421e7ceaa0fc21cf39ac0  ./summary.md
