# Reproducing the 4000-warehouse TPROC-C numbers

## What is in here

| path | what it is |
|---|---|
| `bench/bench-mysql.sh` |  builds each engine, sweeps, runs the peak three times |
| `bench/preflight.sh` | wipes the machine and refuses to start if anything would skew a run |
| `bench/hdb_build_mysql.tcl` | HammerDB schema build |
| `bench/hdb_run_mysql.tcl` | one timed HammerDB run |
| `bench/sample.sh` | per-second engine counters, RSS, cgroup memory, device bytes |
| `bench/extract.py` | pulls one run out of HammerDB's jobs database into `results.csv` |
| `bench/plot.py` | draws every figure from the CSVs |
| `bench/mysql-tidesdb.cnf` | the TidesDB server config, commented with why each setting is there |
| `bench/mysql-innodb.cnf` | the InnoDB server config, same |
| `bench/reference-hammerdb-mysqlio.cnf` | HammerDB's own CI config, for comparison against ours |
| `results.csv` | one row per run, nopm, tpm, new-order latency percentiles, errors |
| `space.csv` | bytes on disk before and after each run, and device bytes written during it |
| `build_times.csv` | build seconds and bytes on disk, with the preallocated log split out |
| `run.json` | the parameters every figure caption is built from |
| `provenance.txt` | exact versions, commit hashes and binary checksums under test |
| `logs/` | raw HammerDB output, server logs, config captures, per-second samples |
| `figures/` | every figure as png, pdf and svg |

## Running it

```sh
cd bench
WH=4000 ./preflight.sh          # wipes and checks; refuses if the box is not clean
PARTITION=false ./bench-mysql.sh
```

Expect roughly nineteen hours.  Two hours of build per engine, then twelve runs
each at about thirty-four minutes, a restore of the whole dataset, ten minutes of
ramp-up, twenty minutes measured.

Smaller, to check the plumbing in about twenty minutes:

```sh
WH=10 BUILDVU=4 VU_LIST="4 8" RAMPUP=1 DURATION=2 PEAK_ITERS=1 \
  OUTDIR=./smoke ./bench-mysql.sh
```

## What the harness insists on

A benchmark that quietly measures the wrong thing is worse than one that fails,
so the harness refuses rather than guesses.

`preflight.sh` stops if any database server, HammerDB or sysbench process is
still alive, if the load average is above 2.0 (a background build would poison a
run), if either filesystem lacks room for the dataset, or if stale benchmark
directories are still on the data device.

`verify_config` runs against the live server before every measured run and
aborts unless the engine under test is actually the default, the binary log is
off, the isolation level is repeatable read, the memory settings took, and for
TidesDB the plugin is active and the sync mode and stall thresholds are what the
config asked for.  It also checks `max_connections` exceeds the highest virtual
user count, because a server that cannot seat every user produces a run with no
transactions in it rather than an error.

Every run restores the database from a copy taken straight after the build and
drops the page cache, so nothing carries over from the run before it.  Each
server runs in a cgroup capped at 96G with swap disabled.

## Reading the numbers

`results.csv` is one row per run.  `nopm` is new orders per minute, the TPC-C
headline; `tpm` is all transactions.  A row with `status` other than `ok` did not
produce a usable result and is not in the article.

`space.csv` carries `dev_bytes_written`, taken from `/proc/diskstats` below the
engine, so it is not either engine's own accounting.  Divide by transactions to
get bytes per transaction.

`build_times.csv` splits `log_prealloc_bytes` out of the total.  InnoDB
preallocates its redo whether the data needs it or not; the TidesDB write-ahead
log grows on demand.  The article quotes the totals.

## Known limits

Both engines run unpartitioned.  HammerDB partitions the order tables above 200
warehouses, but MySQL 8 and up only offers partitioning to an engine that
implements it natively, which InnoDB does and TidesDB does not.  That takes a
recommended tuning away from InnoDB.

Both engines run non-durable, committing to the operating system rather than
waiting on the device.  Neither survives a machine crash in this configuration.
That is the same trade on both sides, but it is not how either would be run in
production.

Compression is off on TidesDB so the space comparison is against an uncompressed
InnoDB.  TidesDB ships with LZ4 on and would be smaller again.

HammerDB does not retry transactions.  TidesDB is optimistic and reports a write
conflict at commit, so its `errors` column counts transactions that did the work
and were then not counted.  InnoDB takes row locks instead and waits, which costs
latency rather than a discarded transaction.  The two columns are not measuring
the same thing.
