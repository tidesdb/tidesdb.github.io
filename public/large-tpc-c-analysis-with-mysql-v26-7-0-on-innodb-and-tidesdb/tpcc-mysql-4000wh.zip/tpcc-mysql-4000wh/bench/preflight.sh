#!/usr/bin/env bash
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"

: "${WH:=4000}"
: "${WIPE:=1}"
: "${BENCHROOT:=/data/mysql-bench}"
: "${SAVED:=/bench-saved-mysql}"
: "${OUTDIR:=/root/sqlanalysis/run4000-mysql}"
: "${MYSQL_BASE:=/data/mysql}"
: "${HDB:=/root/HammerDB-6.0}"

fail=0
ok()   { printf "  \033[32mok\033[0m    %s\n" "$*"; }
warn() { printf "  \033[33mwarn\033[0m  %s\n" "$*"; }
bad()  { printf "  \033[31mFAIL\033[0m  %s\n" "$*"; fail=1; }

echo "== processes that would compete for CPU, memory or the device"
for p in mysqld mariadbd mysqld_safe hammerdbcli java sysbench; do
    n=$(pgrep -x "$p" 2>/dev/null | wc -l)
    [ "$n" -eq 0 ] && ok "no $p" || bad "$n x $p still running -- stop it before running"
done

load=$(awk '{print $1}' /proc/loadavg)
awk -v l="$load" 'BEGIN{exit !(l < 2.0)}' && ok "load average $load" \
    || bad "load average $load -- something is busy"

echo
echo "== wipe"
if [ "$WIPE" = 1 ]; then
    for d in "$BENCHROOT" "$SAVED"; do
        [ -e "$d" ] && { rm -rf "$d" && ok "removed $d"; } || ok "$d absent"
    done
    if [ -e "$OUTDIR" ]; then

        ts=$(date +%Y%m%d-%H%M%S)
        mv "$OUTDIR" "${OUTDIR}.prev-$ts" && warn "existing $OUTDIR moved to ${OUTDIR}.prev-$ts"
    else
        ok "$OUTDIR absent"
    fi
    sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null && ok "page cache dropped"
else
    warn "WIPE=0, nothing removed"
fi

echo
echo "== disk"
need_gib=$(awk -v w="$WH" 'BEGIN{printf "%.0f", 286.0 * w / 3000 * 1.15}')
for mnt in /data /; do
    avail_gib=$(df -BG --output=avail "$mnt" | tail -1 | tr -dc '0-9')
    if [ "${avail_gib:-0}" -ge "$need_gib" ]; then ok "$mnt has ${avail_gib}G free, needs ~${need_gib}G"
    else bad "$mnt has ${avail_gib}G free, needs ~${need_gib}G for $WH warehouses"; fi
done

echo
echo "== memory"
total_gib=$(awk '/MemTotal/{printf "%.0f", $2/1048576}' /proc/meminfo)
[ "$total_gib" -ge 100 ] && ok "${total_gib}G RAM (96G cgroup cap + headroom)" \
    || bad "${total_gib}G RAM is too little for a 96G cap"
swapon --show=NAME --noheadings 2>/dev/null | grep -q . \
    && warn "swap is on; the cgroup sets MemorySwapMax=0 so this should not matter" \
    || ok "no swap"

echo
echo "== build under test"
[ -x "$MYSQL_BASE/bin/mysqld" ] && ok "mysqld: $("$MYSQL_BASE/bin/mysqld" --version 2>/dev/null | awk '{print $3}')" \
    || bad "no mysqld at $MYSQL_BASE/bin"
[ -f "$MYSQL_BASE/lib/plugin/ha_tidesdb.so" ] \
    && ok "plugin: ha_tidesdb.so $(stat -c %y "$MYSQL_BASE/lib/plugin/ha_tidesdb.so" | cut -d. -f1)" \
    || bad "no ha_tidesdb.so"
lib=$(readlink -f /usr/local/lib/libtidesdb.so 2>/dev/null)
[ -n "$lib" ] && ok "library: $(basename "$lib") $(stat -c %y "$lib" | cut -d. -f1)" \
    || bad "libtidesdb.so not installed"
[ -d "$HDB" ] && ok "HammerDB at $HDB" || bad "no HammerDB at $HDB"

echo
echo "== leftovers from earlier work on the data device"
stale=$(ls -d /data/lb-* /data/launch-* /data/bigval-* /data/minimal-* 2>/dev/null)
[ -z "$stale" ] && ok "no stale benchmark directories" || { echo "$stale" | sed 's/^/        /'; bad "stale directories present"; }

echo
if [ "$fail" = 0 ]; then
    echo "preflight clean -- safe to start the benchmark"
else
    echo "preflight FAILED -- fix the above before starting"; exit 1
fi
