proc need {n} { if {![info exists ::env($n)]} { puts "BENCH_ERROR missing env $n"; exit 1 }; return $::env($n) }
dbset db mysql
dbset bm TPC-C
diset connection mysql_host localhost
diset connection mysql_port 3306
diset connection mysql_socket [need SOCKET]
diset tpcc mysql_user hammer
diset tpcc mysql_pass hammer
diset tpcc mysql_dbase tpcc
diset tpcc mysql_driver      timed
diset tpcc mysql_rampup      [need RAMPUP]
diset tpcc mysql_duration    [need DURATION]

diset tpcc mysql_allwarehouse true
diset tpcc mysql_timeprofile true
diset tpcc mysql_keyandthink false

diset tpcc mysql_raiseerror  false
giset commandline keepalive_margin 1200
giset timeprofile  xt_gather_timeout 1200

tcset refreshrate 1
tcset timestamps 1
loadscript
vuset vu [need VU]
vuset logtotemp 1
vucreate
tcstart
tcstatus
set raw [vurun]
tcstop
catch { vudestroy }
set jobid ""
if {![regexp {jobid=([0-9A-Za-z]+)} $raw -> jobid]} { regexp {([0-9A-Fa-f]{16,})} $raw jobid }
puts "BENCH_JOBID $jobid"
