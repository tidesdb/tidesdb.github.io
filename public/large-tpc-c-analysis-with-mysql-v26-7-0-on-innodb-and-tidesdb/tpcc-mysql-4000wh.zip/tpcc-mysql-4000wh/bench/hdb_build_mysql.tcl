proc need {n} { if {![info exists ::env($n)]} { puts "BENCH_ERROR missing env $n"; exit 1 }; return $::env($n) }
dbset db mysql
dbset bm TPC-C
diset connection mysql_host localhost
diset connection mysql_port 3306
diset connection mysql_socket [need SOCKET]
diset tpcc mysql_user hammer
diset tpcc mysql_pass hammer
diset tpcc mysql_dbase tpcc
diset tpcc mysql_count_ware     [need WH]
diset tpcc mysql_num_vu         [need BUILDVU]
diset tpcc mysql_storage_engine [need ENGINE]
diset tpcc mysql_partition      [need PARTITION]
diset tpcc mysql_history_pk     false
giset commandline keepalive_margin 7200
puts "BENCH_BUILD_START"
buildschema
catch { vudestroy }
puts "BENCH_BUILD_DONE"
checkschema
catch { vudestroy }
puts "BENCH_CHECK_DONE"
