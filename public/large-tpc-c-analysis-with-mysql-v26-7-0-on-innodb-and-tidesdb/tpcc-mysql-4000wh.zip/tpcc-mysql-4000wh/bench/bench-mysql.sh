
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${OUTDIR:=/root/sqlanalysis/run4000-mysql}"
: "${ENGINES:=tidesdb innodb}"
: "${WH:=4000}"
: "${BUILDVU:=24}"
: "${VU_LIST:=4 8 16 32 64 128 256 512 1024}"
: "${RAMPUP:=10}"
: "${DURATION:=20}"
: "${PEAK_ITERS:=3}"
: "${PARTITION:=$([ "$WH" -ge 200 ] && echo true || echo false)}"  
: "${MEMMAX:=96G}"          
: "${SAVED:=/bench-saved-mysql}"  
: "${SAMPLE_INT:=1}"       
: "${STALL_FLOOR:=1000}"  
: "${KEEP_SAVED:=0}"
: "${CPUS:=$(lscpu -p=CPU,ONLINE | awk -F, '!/^#/ && $2=="Y"{printf "%s%s",s,$1; s=","}')}"

BASE=/data/mysql; BIN=$BASE/bin
BENCHROOT=/data/mysql-bench; DATADIR=$BENCHROOT/data; TDBDIR=$BENCHROOT/tidesdb_data
SOCK=/tmp/mysql-bench.sock; HDB=/root/HammerDB-6.0
M="$BIN/mysql -uroot --socket=$SOCK --protocol=socket"
declare -A CNF=([tidesdb]=$HERE/mysql-tidesdb.cnf [innodb]=$HERE/mysql-innodb.cnf)
declare -A LABEL=([tidesdb]=TidesDB [innodb]=InnoDB)

TDB_CACHE_BYTES=$(( 60 * 1024 * 1024 * 1024 ))
INNODB_POOL_BYTES=$(( 64 * 1024 * 1024 * 1024 ))

mkdir -p "$OUTDIR"/{logs,data,cnf} "$SAVED" "$BENCHROOT"
export TMP="$OUTDIR/hdbtmp"; mkdir -p "$TMP"
export WH BUILDVU PARTITION RAMPUP DURATION
export SOCKET="$SOCK"
JOBSDB="$TMP/hammer.DB"
LOG="$OUTDIR/bench.log"
log() { echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }
die() { log "FATAL: $*"; stop_server; exit 1; }

srv_pids() { pgrep -x mysqld; }
server_up() { $M -N -B -e "SELECT 1" >/dev/null 2>&1; }

stop_server() {
    server_up && "$BIN/mysqladmin" -uroot --socket="$SOCK" shutdown >/dev/null 2>&1
    for _ in $(seq 600); do [ -z "$(srv_pids)" ] && break; sleep 1; done
    if [ -n "$(srv_pids)" ]; then log "server did not stop, killing"; kill -9 $(srv_pids) 2>/dev/null; sleep 3; fi
    rm -f "$DATADIR/mysqld.pid" "$SOCK"
    return 0
}

start_server() {   
    [ -z "$(srv_pids)" ] || die "a server is already running"
    systemd-run --scope -q --unit="bench-$$-$RANDOM" -p MemoryMax="$MEMMAX" -p MemorySwapMax=0 \
        taskset -c "$CPUS" env LD_LIBRARY_PATH=/usr/local/lib \
        "$BIN/mysqld" --defaults-file="$1" \
        >"$OUTDIR/logs/server-$2.log" 2>&1 &
    for _ in $(seq 900); do server_up && return 0; sleep 1; done
    tail -30 "$DATADIR/mysqld.err" >>"$LOG" 2>/dev/null
    die "server failed to start ($2)"
}

verify_config() {  
    local e=$1 tag=$2 mode=$3 f="$OUTDIR/logs/config-$2.txt" bad=""
    $M -N -B -e "SELECT @@version; SHOW GLOBAL VARIABLES;
                 SELECT PLUGIN_NAME,PLUGIN_STATUS FROM information_schema.PLUGINS
                 WHERE PLUGIN_TYPE='STORAGE ENGINE';" >"$f" 2>&1
    v() { awk -v k="$1" '$1==k{print $2; exit}' "$f"; }

    near() { awk -v a="${1:-0}" -v b="$2" 'BEGIN{exit !(a>0 && (a>b?a-b:b-a) <= b*0.02)}'; }
    local want; want=$([ "$e" = tidesdb ] && echo TidesDB || echo InnoDB)
    [ "$(v default_storage_engine)" = "$want" ] || bad+=" engine=$(v default_storage_engine)"
    [ "$(v log_bin)" = "OFF" ] || bad+=" log_bin=$(v log_bin)"

    local maxvu; maxvu=$(echo "$VU_LIST" | tr ' ' '\n' | sort -n | tail -1)
    awk -v c="$(v max_connections)" -v n="$maxvu" 'BEGIN{exit !(c > n + 20)}' \
        || bad+=" max_connections=$(v max_connections) for ${maxvu}VU"
    if [ "$mode" = run ]; then
        [ "$(v transaction_isolation)" = "REPEATABLE-READ" ] || bad+=" iso=$(v transaction_isolation)"
        if [ "$e" = tidesdb ]; then
            [ "$(v tidesdb_memtable_sync_mode)" = "NONE" ] || bad+=" sync=$(v tidesdb_memtable_sync_mode)"
            near "$(v tidesdb_block_cache_size)" "$TDB_CACHE_BYTES" || bad+=" cache=$(v tidesdb_block_cache_size)"
            [ "$(v tidesdb_max_open_sstables)" = "65536" ] || bad+=" open_sst=$(v tidesdb_max_open_sstables)"
            [ "$(v tidesdb_log_level)" = "NONE" ] || bad+=" log_level=$(v tidesdb_log_level)"
            [ "$(v tidesdb_compaction_threads)" = "4" ] || bad+=" compaction_threads=$(v tidesdb_compaction_threads)"
            [ "$(v tidesdb_memtable_l0_queue_stall_threshold)" = "30" ] || bad+=" l0_stall=$(v tidesdb_memtable_l0_queue_stall_threshold)"
            grep -qiE "^TidesDB[[:space:]]+ACTIVE" "$f" || bad+=" plugin-not-active"
        else
            [ "$(v innodb_flush_log_at_trx_commit)" = "0" ] || bad+=" flush=$(v innodb_flush_log_at_trx_commit)"
            [ "$(v innodb_doublewrite)" = "ON" ] || bad+=" doublewrite=$(v innodb_doublewrite)"
            near "$(v innodb_buffer_pool_size)" "$INNODB_POOL_BYTES" || bad+=" pool=$(v innodb_buffer_pool_size)"
            [ "$(v innodb_buffer_pool_instances)" = "16" ] || bad+=" pool_instances=$(v innodb_buffer_pool_instances)"
            [ "$(v innodb_io_capacity)" = "4000" ] || bad+=" io_capacity=$(v innodb_io_capacity)"
            [ "$(v innodb_page_cleaners)" = "8" ] || bad+=" page_cleaners=$(v innodb_page_cleaners)"
            [ "$(v innodb_adaptive_hash_index)" = "OFF" ] || bad+=" ahi=$(v innodb_adaptive_hash_index)"
        fi
    fi
    [ -z "$bad" ] || die "config check failed ($tag):$bad"
    log "config ok ($tag): $(head -1 "$f") $want $mode"
}


save_copy() {   
    rm -rf "$1"; mkdir -p "$1"
    cp -a "$DATADIR" "$1/data"
    [ -d "$TDBDIR" ] && cp -a "$TDBDIR" "$1/tidesdb_data"
    sync
}

restore_copy() {   
    [ -d "$1/data" ] || die "no copy at $1"
    stop_server
    [ -n "${2:-}" ] && [ -f "$DATADIR/mysqld.err" ] && cp "$DATADIR/mysqld.err" "$OUTDIR/logs/err-$2.log"
    rm -rf "$DATADIR" "$TDBDIR"
    cp -a "$1/data" "$DATADIR"
    [ -d "$1/tidesdb_data" ] && cp -a "$1/tidesdb_data" "$TDBDIR"
    sync; echo 3 > /proc/sys/vm/drop_caches
}

make_pristine() {
    [ -d "$SAVED/pristine/data" ] && { log "pristine copy exists"; return; }
    log "initialising a fresh MySQL datadir"
    rm -rf "$DATADIR" "$TDBDIR"; mkdir -p "$BENCHROOT"
    local icnf="$OUTDIR/cnf/init.cnf"
    { echo "[mysqld]"; echo "user=root"; echo "datadir=$DATADIR"
      echo "socket=$SOCK"; echo "port=3306"; echo "skip-log-bin"
      echo "log-error=$DATADIR/mysqld.err"; } >"$icnf"
    LD_LIBRARY_PATH=/usr/local/lib "$BIN/mysqld" --defaults-file="$icnf" \
        --initialize-insecure --basedir="$BASE" >"$OUTDIR/logs/initialize.log" 2>&1 \
        || { tail -20 "$OUTDIR/logs/initialize.log" >>"$LOG"; die "datadir initialise failed"; }
    start_server "$icnf" pristine
    $M -e "CREATE USER IF NOT EXISTS 'hammer'@'localhost' IDENTIFIED WITH mysql_native_password BY 'hammer';" 2>/dev/null \
      || $M -e "CREATE USER IF NOT EXISTS 'hammer'@'localhost' IDENTIFIED BY 'hammer';" \
      || die "could not create hammer user"
    $M -e "CREATE USER IF NOT EXISTS 'hammer'@'127.0.0.1' IDENTIFIED BY 'hammer';" >/dev/null 2>&1
    $M -e "GRANT ALL PRIVILEGES ON *.* TO 'hammer'@'localhost' WITH GRANT OPTION;
           DROP DATABASE IF EXISTS tpcc;" || die "could not grant to hammer"
    $M -e "GRANT ALL PRIVILEGES ON *.* TO 'hammer'@'127.0.0.1' WITH GRANT OPTION;" >/dev/null 2>&1
    stop_server; rm -rf "$TDBDIR"
    save_copy "$SAVED/pristine"
}

hdb() {  
    ( cd "$HDB" && timeout --signal=KILL "$1" taskset -c "$CPUS" ./hammerdbcli auto "$2" ) >"$3" 2>&1
}

stall_watch() {   
    local tag=$1 rl=$2 low=0
    sleep $(( RAMPUP * 60 + 60 ))
    while kill -0 "$HDB_PID" 2>/dev/null; do
        local tpm; tpm=$(grep -aoE "^[0-9]+ MySQL tpm" "$rl" | tail -1 | awk '{print $1}')
        if [ -n "$tpm" ] && [ "$tpm" -lt "$STALL_FLOOR" ]; then
            low=$((low+1))
            if [ "$low" -ge 2 ]; then
                log "STALL detected in $tag (tpm=$tpm) -- capturing diagnostics"
                local d="$OUTDIR/logs/stall-$tag"; mkdir -p "$d"
                $M -e "SHOW ENGINE ${ENG_UP} STATUS" >"$d/engine-status.txt" 2>&1
                $M -e "SHOW FULL PROCESSLIST" >"$d/processlist.txt" 2>&1
                local pid; pid=$(pgrep -x mysqld | head -1)
                cat /proc/$pid/status >"$d/proc-status.txt" 2>&1
                timeout 60 gdb -p "$pid" -batch -ex "set pagination off" \
                    -ex "thread apply all bt 20" >"$d/stacks.txt" 2>&1
                timeout 35 perf record -F 99 -g -p "$pid" -o "$d/perf.data" -- sleep 30 >/dev/null 2>&1
                log "STALL diagnostics in $d"
                low=0
            fi
        else low=0; fi
        sleep 30
    done
}

build_engine() {
    local e=$1 bcnf="$OUTDIR/cnf/build-$e.cnf"
    if [ "${REBUILD:-0}" != 1 ] && [ -d "$SAVED/$e/data" ]; then
        log "saved copy for $e exists, skipping build (REBUILD=1 to force)"
        return 0
    fi
    cp "${CNF[$e]}" "$bcnf"
    { echo; echo "[mysqld]"; echo "# ---- BUILD overlay (bench-mysql.sh), not a measured run ----"
      echo "transaction_isolation=READ-COMMITTED"; } >>"$bcnf"
    restore_copy "$SAVED/pristine"
    start_server "$bcnf" "build-$e"
    verify_config "$e" "build-$e" build
    log "building $e: $WH WH, $BUILDVU build VUs, partition=$PARTITION"
    local t0=$SECONDS
    export ENGINE=$e
    hdb $(( WH * 20 + 3600 )) "$HERE/hdb_build_mysql.tcl" "$OUTDIR/logs/hdb-build-$e.log"
    local secs=$(( SECONDS - t0 ))
    grep -q BENCH_CHECK_DONE "$OUTDIR/logs/hdb-build-$e.log" || die "build/check failed for $e"
    grep -qiE "Error in Virtual User|FINISHED FAILED" "$OUTDIR/logs/hdb-build-$e.log" && die "build had VU errors ($e)"
    $M -N -B -e "SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA='tpcc'" \
        >"$OUTDIR/logs/tables-$e.txt"
    local want; want=$([ "$e" = tidesdb ] && echo TidesDB || echo InnoDB)
    awk -v w="$want" 'tolower($2)!=tolower(w){bad=1} END{exit bad}' "$OUTDIR/logs/tables-$e.txt" \
        || die "tpcc tables not all $want"
    stop_server
    local size; size=$(du -sb "$DATADIR" "$TDBDIR" 2>/dev/null | awk '{s+=$1} END{print s}')

    local logbytes
    logbytes=$(find "$DATADIR" \( -path '*#innodb_redo*' -o -name 'ib_logfile*' \) -type f 2>/dev/null \
               | xargs -r stat -c %s 2>/dev/null | awk '{s+=$1} END{print s+0}')
    [ -f "$OUTDIR/build_times.csv" ] || echo "engine,warehouses,build_vu,build_seconds,bytes_on_disk,log_prealloc_bytes,data_bytes" >"$OUTDIR/build_times.csv"
    echo "${LABEL[$e]},$WH,$BUILDVU,$secs,$size,$logbytes,$(( size - logbytes ))" >>"$OUTDIR/build_times.csv"
    log "built $e in ${secs}s, $(numfmt --to=iec "$size"); saving a copy to restore from"
    save_copy "$SAVED/$e"
}

one_run() {  
    local e=$1 ph=$2 vu=$3 it=$4 tag="$1-$3vu-$2-$4"
    restore_copy "$SAVED/$e" "$tag"
    start_server "${CNF[$e]}" "run-$tag"
    verify_config "$e" "run-$tag" run
    ENG_UP=$([ "$e" = tidesdb ] && echo TIDESDB || echo INNODB)
    SAMPLE_CLIENT="$M" SAMPLE_PROC=mysqld \
        "$HERE/sample.sh" "$OUTDIR/logs/sample-$tag.csv" "$e" "$SAMPLE_INT" & local SP=$!
    $M -e "SHOW ENGINE $ENG_UP STATUS" >"$OUTDIR/logs/status-$tag-before.txt" 2>&1
    local sz0 dev0; sz0=$(du -sb "$DATADIR" "$TDBDIR" 2>/dev/null | awk '{s+=$1} END{print s+0}')
    dev0=$(awk -v d="$(findmnt -no SOURCE --target /data | sed 's|/dev/||')" '$3==d{print $10*512; exit}' /proc/diskstats)
    log "run $tag: ${RAMPUP}m rampup + ${DURATION}m measure"
    export VU=$vu
    local rl="$OUTDIR/logs/hdb-$tag.log"
    hdb $(( (RAMPUP + DURATION) * 60 + 900 )) "$HERE/hdb_run_mysql.tcl" "$rl" & HDB_PID=$!
    stall_watch "$tag" "$rl" & local WP=$!
    wait $HDB_PID; local rc=$?
    kill $WP 2>/dev/null; kill $SP 2>/dev/null
    local timed_out=0
    { [ $rc -eq 137 ] || [ $rc -eq 124 ]; } && { timed_out=1; log "run $tag TIMED OUT"; }
    local jobid; jobid=$(awk '/BENCH_JOBID/{print $2}' "$rl" | tail -1)
    local jdb; jdb=$(grep -aoE "on-disk database [^ ]+" "$rl" | awk '{print $3}' | tail -1)
    [ -n "$jdb" ] && [ -f "$jdb" ] && JOBSDB=$jdb
    $M -e "SHOW ENGINE $ENG_UP STATUS" >"$OUTDIR/logs/status-$tag-after.txt" 2>&1
    local sz1 dev1; sz1=$(du -sb "$DATADIR" "$TDBDIR" 2>/dev/null | awk '{s+=$1} END{print s+0}')
    dev1=$(awk -v d="$(findmnt -no SOURCE --target /data | sed 's|/dev/||')" '$3==d{print $10*512; exit}' /proc/diskstats)
    [ -f "$OUTDIR/space.csv" ] || echo "engine,phase,vu,iter,bytes_before,bytes_after,bytes_grown,dev_bytes_written" >"$OUTDIR/space.csv"
    echo "${LABEL[$e]},$ph,$vu,$it,$sz0,$sz1,$(( sz1 - sz0 )),$(( dev1 - dev0 ))" >>"$OUTDIR/space.csv"
    python3 "$HERE/extract.py" "$JOBSDB" "$OUTDIR" "${LABEL[$e]}" "$ph" "$vu" "$it" "${jobid:--}" "$timed_out" | tee -a "$LOG"
    stop_server
}

peak_vu() { awk -F, -v e="${LABEL[$1]}" '$1==e && $2=="sweep" && $13=="ok" && $5>b {b=$5; v=$3} END{print v}' "$OUTDIR/results.csv"; }

write_run_json() {
    python3 - "$OUTDIR/run.json" <<EOF
import json, subprocess, sys
v = subprocess.run(["$BIN/mysqld","--version"], capture_output=True, text=True).stdout.split()[2]
json.dump({
 "mysql_version": v, "tidesdb_version": "master", "tidesql_mysql_version": "2.0.0",
 "hammerdb_version": "6.0", "warehouses": $WH, "build_vu": $BUILDVU,
 "partition": "$PARTITION" == "true", "vu_list": [int(x) for x in "$VU_LIST".split()],
 "rampup_min": $RAMPUP, "duration_min": $DURATION, "peak_iters": $PEAK_ITERS,
 "isolation": "REPEATABLE READ",
 "durability": "non-durable (commit to OS, doublewrite on, binlog off)",
 "use_all_warehouses": True, "sample_interval_s": $SAMPLE_INT,
 "memory": "64G each: InnoDB buffer pool 64G; TidesDB 60G block cache + 4G memtable. "
           "cgroup MemoryMax=$MEMMAX, caches dropped before each run",
 "state": "database restored from a saved copy of the built schema before every run",
 "host": "i9-13900 (8P+16E, 24 threads), 125 GB RAM, NVMe; HammerDB on the same host",
 "cpus": "$CPUS"}, open(sys.argv[1],"w"), indent=1)
EOF
}

record_provenance() {
    local f="$OUTDIR/provenance.txt"
    {
        echo "recorded      $(date -Is)"
        echo "mysqld        $("$BIN/mysqld" --version 2>/dev/null)"
        echo "plugin        $(sha256sum "$BASE/lib/plugin/ha_tidesdb.so" 2>/dev/null | cut -c1-16)  $(stat -c %y "$BASE/lib/plugin/ha_tidesdb.so" 2>/dev/null | cut -d. -f1)"
        local lib; lib=$(readlink -f /usr/local/lib/libtidesdb.so 2>/dev/null)
        echo "libtidesdb    $(basename "${lib:-none}")  $(sha256sum "$lib" 2>/dev/null | cut -c1-16)"
        for r in /tmp/tidesql-build/tidesdb-lib /root/tidesql-mysql; do
            [ -d "$r/.git" ] && echo "$(printf '%-13s' "$(basename "$r")") $(git -C "$r" rev-parse HEAD 2>/dev/null) $(git -C "$r" rev-parse --abbrev-ref HEAD 2>/dev/null)"
        done
        echo "hammerdb      $(cat "$HDB"/version.txt 2>/dev/null || echo 6.0)"
        echo "kernel        $(uname -r)"
        echo "cpu           $(lscpu | awk -F: '/Model name/{gsub(/^ +/,"",$2); print $2; exit}')"
        echo "ram           $(awk '/MemTotal/{printf "%.0f GiB", $2/1048576}' /proc/meminfo)"
        echo "data device   $(findmnt -no SOURCE --target /data)"
    } >"$f"
    log "provenance recorded in $f"
}

log "=== start: engines=[$ENGINES] WH=$WH VU=[$VU_LIST] ${RAMPUP}+${DURATION}m peak=$PEAK_ITERS mem=$MEMMAX"
[ -x "$BIN/mysqld" ] || die "no mysqld at $BIN"
[ -d "$HDB" ] || die "no HammerDB at $HDB"
cp "${CNF[tidesdb]}" "${CNF[innodb]}" "$OUTDIR/cnf/"
cp /root/sqlanalysis/plot.py "$OUTDIR/" 2>/dev/null
mkdir -p "$OUTDIR/bench"
cp "$HERE"/{bench-mysql.sh,hdb_build_mysql.tcl,hdb_run_mysql.tcl,sample.sh,extract.py,preflight.sh} \
   "$HERE"/mysql-tidesdb.cnf "$HERE"/mysql-innodb.cnf "$OUTDIR/bench/" 2>/dev/null
record_provenance
write_run_json
stop_server
make_pristine

for e in $ENGINES; do
    build_engine "$e"
    for vu in $VU_LIST; do one_run "$e" sweep "$vu" 1; done
    pv=$(peak_vu "$e")
    if [ -n "$pv" ] && [ "$PEAK_ITERS" -gt 0 ]; then
        log "$e peak at $pv VU; $PEAK_ITERS runs there"
        for i in $(seq 1 "$PEAK_ITERS"); do one_run "$e" peak "$pv" "$i"; done
    else
        log "$e: no ok sweep run to take a peak from"
    fi
    [ "$KEEP_SAVED" = 1 ] || { log "removing saved copy for $e"; rm -rf "$SAVED/$e"; }
done

restore_copy "$SAVED/pristine" final
log "=== done; plotting"
( cd "$OUTDIR" && python3 plot.py --dir . ) 2>&1 | tee -a "$LOG"
