# Reproducing the TideSQL-MySQL v2.0.0 launch numbers

Everything needed to re-run the measurements in the launch article: the harness,
the sysbench scripts, the raw sysbench output of every run, the parsed results,
and the figures. No step in the article was done by hand.

## What was measured, and on what

| | |
|---|---|
| server | MySQL 26.7.0, built from source |
| engine under test | TideSQL-MySQL v2.0.0, on TidesDB v10.1.1 |
| reference engine | InnoDB, same server binary |
| client | sysbench 1.0.20 |
| host | Intel i9-13900 (8 P-core + 16 E-core, 24 threads), 125 GiB DDR5, NVMe Micron 7450 on xfs, Ubuntu 24.04.4 |

Both engines run inside the same `mysqld`, so the server, the client, the
machine and the filesystem are identical and the engine is the only variable.

## Building the stack

```sh
git clone https://github.com/tidesdb/tidesql-mysql && cd tidesql-mysql
./install.sh --mysql-version mysql-26.7.0 \
             --mysql-prefix /data/mysql \
             --tidesdb-prefix /usr/local \
             --build-dir /data/tidesql-mysql-build \
             --skip-engines archive,blackhole,example,federated,ndb \
             --allocator jemalloc --jobs 16
```

On Ubuntu 24.04 the build also needs `libtirpc-dev`, which the installer's
dependency list does not cover: `apt-get install -y libtirpc-dev`.

The installer's `--allocator` only covers libtidesdb's own allocations. The
harness additionally `LD_PRELOAD`s jemalloc for the whole `mysqld` process, which
is how the earlier MariaDB runs were done and what the installer recommends for a
process-wide swap.

## Running the measurements

Three scripts, each independent, each writing its own results directory.

```sh
./bench.sh        # throughput, latency and write amplification   ~1.4 h
./bigvalue.sh     # large values, where the shared value log engages  ~25 min
```

Every parameter is an environment variable with the published value as its
default, so a different shape is one variable away:

```sh
THREADS="16 24 32 48" DURATION=300 ./bench.sh
VALUE_SIZE=16384 ./bigvalue.sh
```

## What each script does, and why

### `bench.sh`

Five workloads at two thread counts, per engine: `point_select`, `read_write`,
`update_index`, `write_only`, `delete`.

Three things in it are not optional, and each exists because leaving it out
produced a wrong number earlier in this work:

- **The cache is warmed by a full scan before timing.** A dataset sized to fit in
  cache is not the same as a dataset resident in cache: a random point lookup
  only caches rows it touches, so warming ~8 GB at a few hundred thousand lookups
  a second takes minutes. Without the scan the point-lookup figure measures the
  device while claiming to measure the engine.
- **120 s measured after 60 s warmup.** A 30 s window was tried first and is too
  short: in earlier sysbench work TidesDB settled inside it but InnoDB did not,
  drifting -14.5% on `write_only` while climbing +56% on `update_index` as its
  buffer pool warmed. A window that catches one engine mid-transient in different
  directions per workload is worse than a uniformly biased one.
- **A 30 s settle before the write counter closes.** TidesDB with
  `memtable_sync_mode=NONE` and a multi-GB memtable can finish a short run having
  written almost nothing to the device. Those writes still have to happen, so
  they are charged to the run that caused them rather than silently credited as
  savings.

`delete` runs on a **freshly reloaded dataset**, because `oltp_delete` removes
rows by random id and never reinserts them. Run on a used dataset it measures
deletes that match nothing.

Write amplification comes from `/proc/diskstats` rather than from either engine's
own accounting, so both engines are measured the same way, below the engine, by
the same kernel counter.

### `bigvalue.sh` and `lua/bigvalue.lua`

No workload in the standard sysbench set crosses TidesDB's value separation
threshold: an sbtest row is about 188 bytes against a 1024 byte default, so none
of them put anything in the shared value log. `bigvalue.lua` sizes its value
column with `--value_size` specifically to cross it.

Three configurations, not two:

| config | what it is |
|---|---|
| `innodb` | uncompressed, for reference |
| `tidesdb` | as it ships, values above the threshold go to the value log |
| `tidesdb-inline` | same engine, same data, `ENGINE_ATTRIBUTE='{"keep_values_inline": true}'` |

The third isolates the value log. A TidesDB-versus-InnoDB difference on large
values could be anything about the engine; with `keep_values_inline` toggled on
the same engine and the same data, whatever moves is the value log's doing.

`lua/bigvalue.lua` is self-contained and depends on no other sysbench script, so
it can be read, checked and re-run on its own.

## Output

| file | contents |
|---|---|
| `run/results.csv` | one row per run: tps, p95, events, device bytes written, bytes per operation |
| `run/space.csv` | bytes on disk after load, after writes, after deletes |
| `run/raw/*.out` | the unedited sysbench output of every run, including per-second samples |
| `run/run.json` | server version, dataset, thread counts, window sizes, host |
| `run/results-firstpass.csv` | superseded, see below |
| `run/delete-rerun/` | the delete workload re-run, and the numbers the article uses for it |
| `run/rss.csv` | sampled server RSS; not used in the article, see below |
| `bigvalue-run/` | the same shape for the large-value runs, plus `space.csv` |
| `*/figures/` | the figures as published |

`plot.sh` and `bigvalue-plot.sh` draw the figures from the CSVs with gnuplot, so
they can be redrawn without re-running anything.

Two files need explaining rather than quietly shipping.

`results-firstpass.csv` holds a first pass whose delete numbers are wrong.  It
loaded the dataset once and then ran delete at both thread counts, so the 24
thread run removed a large part of the table and the 32 thread run was mostly
deleting rows that were already gone.  `bench.sh` now reloads before each thread
count and `run/delete-rerun/` is that corrected run.  The article uses the rerun.
The first pass is kept so the two can be compared.

`rss.csv` is a resident-set sample taken across the whole session, load and
warmup included.  TidesDB's memory is transient by design -- its queues are
sized generously and drain in the background -- so a median taken that way says
very little, and no memory claim is made in the article on the strength of it.

## Known limits of these numbers

- The dataset is sized to fit in cache, deliberately, so these measure engine
  code paths rather than device behaviour. Larger-than-memory is a different
  question and is covered separately.
- Runs are two minutes. Long enough for throughput to settle on both engines, not
  long enough for LSM compaction to reach equilibrium, so space figures are
  accumulation before reclamation rather than a steady-state footprint.
- Every access pattern is uniform random or sequential. A skewed distribution
  would favour both engines' caches differently.
- Two thread counts, 24 and 32, bracketing the host's 24 hardware threads.
