#!/usr/bin/env bash
# Large values: what the shared value log actually does.
#
# No sysbench workload in the standard set crosses TidesDB's value separation
# threshold -- an sbtest row is about 188 bytes against a 1024 byte default --
# so none of them exercise the value log at all.  This runs bigvalue.lua, whose
# value column is sized by --value_size, across three configurations:
#
#   innodb                InnoDB, uncompressed, for reference
#   tidesdb               TidesDB as it ships: LZ4, values above the threshold
#                         go to the shared value log
#   tidesdb-inline        TidesDB with keep_values_inline, which holds every
#                         value in the key log whatever its size
#
# The third exists because it isolates the value log: same engine, same data,
# one table option different.  Without it a TidesDB-vs-InnoDB difference could
# be anything about the engine; with it the value log's contribution is visible
# on its own.
set -u

BASE=/data/mysql
BIN=$BASE/bin
HERE=$(cd "$(dirname "$0")" && pwd)
SB=${SB:-$(command -v sysbench)}

CONFIGS=${CONFIGS:-innodb tidesdb tidesdb-inline}
THREADS=${THREADS:-24 32}
TABLES=${TABLES:-4}
ROWS=${ROWS:-200000}
VALUE_SIZE=${VALUE_SIZE:-4096}
DURATION=${DURATION:-60}
WARMUP=${WARMUP:-20}
OUTDIR=${OUTDIR:-$HERE/bigvalue-run}

SOCK=/tmp/bigval-mysql.sock
DB=bigval

die() { echo "FATAL: $*" >&2; exit 1; }
log() { echo "$(date -Is) $*" | tee -a "$OUTDIR/bench.log"; }

srv_up() { pgrep -x mysqld >/dev/null; }
stop_server() {
    srv_up || return 0
    "$BIN/mysqladmin" --socket="$SOCK" -u root shutdown >/dev/null 2>&1
    for _ in $(seq 60); do srv_up || return 0; sleep 1; done
    kill -9 $(pgrep -x mysqld) 2>/dev/null; sleep 2
}
trap stop_server EXIT INT TERM

engine_of() { case $1 in innodb) echo innodb ;; *) echo tidesdb ;; esac; }

start_server() {   # config
    local c=$1 dd cf extra=()
    dd=/data/bigval-$c; cf=/data/bigval-$c-cf
    if [ "$(engine_of "$c")" = tidesdb ]; then
        extra+=(--plugin-load-add=ha_tidesdb.so --default-storage-engine=TidesDB
                --tidesdb-data-home-dir="$cf"
                --tidesdb-log-level=NONE --tidesdb-log-to-file=OFF
                --tidesdb-memtable-sync-mode=NONE)
    else
        extra+=(--default-storage-engine=InnoDB
                --innodb-flush-log-at-trx-commit=0)
    fi
    LD_LIBRARY_PATH=/usr/local/lib LD_PRELOAD=/lib/x86_64-linux-gnu/libjemalloc.so.2 \
    "$BIN/mysqld" --no-defaults --user=root --basedir="$BASE" --datadir="$dd" \
        --socket="$SOCK" --skip-networking --skip-log-bin --performance-schema=OFF \
        --transaction-isolation=READ-COMMITTED \
        --log-error="$dd/err.log" --plugin-dir="$BASE/lib/plugin" \
        "${extra[@]}" >>"$OUTDIR/logs/server-$c.out" 2>&1 &
    for _ in $(seq 180); do
        "$BIN/mysql" --socket="$SOCK" -u root -e "select 1" >/dev/null 2>&1 && return 0
        sleep 1
    done
    tail -25 "$dd/err.log"; die "$c did not start"
}

sqlq() { "$BIN/mysql" --socket="$SOCK" -u root -N -B -e "$1" 2>/dev/null; }

space_of() {  # config
    local dd cf total pre
    dd=/data/bigval-$1; cf=/data/bigval-$1-cf
    total=$(du -sb "$dd" "$cf" 2>/dev/null | awk '{s+=$1} END{print s+0}')
    pre=$(find "$dd" \( -path '*#innodb_redo*' -o -name 'ib_logfile*' -o -name 'undo_*' \) 2>/dev/null \
          | xargs -r stat -c %s 2>/dev/null | awk '{s+=$1} END{print s+0}')
    echo "$(( total - pre ))"
}

sb() {  # config args...
    local c=$1; shift
    local opts=""
    [ "$c" = tidesdb-inline ] && opts='ENGINE_ATTRIBUTE='"'"'{"keep_values_inline": true}'"'"''
    LUA_PATH="$HERE/lua/?.lua;;" "$SB" "$HERE/lua/bigvalue.lua" \
        --db-driver=mysql --mysql-socket="$SOCK" --mysql-user=root --mysql-db="$DB" \
        --tables="$TABLES" --table_size="$ROWS" --value_size="$VALUE_SIZE" \
        --rand-type=uniform \
        --engine="$(engine_of "$c")" --create_opts="$opts" "$@"
}

mkdir -p "$OUTDIR/logs" "$OUTDIR/raw"
: > "$OUTDIR/bench.log"
echo "config,workload,threads,tps,p95_ms" > "$OUTDIR/results.csv"
echo "config,load_seconds,bytes,logical_bytes" > "$OUTDIR/space.csv"

[ -x "$SB" ] || die "no sysbench"
srv_up && die "a mysqld is already running"
logical=$(( TABLES * ROWS * VALUE_SIZE ))
log "value size $VALUE_SIZE B, $TABLES tables x $ROWS rows = $(numfmt --to=iec $logical) of payload"

for c in $CONFIGS; do
    log "=== $c ==="
    stop_server
    rm -rf "/data/bigval-$c" "/data/bigval-$c-cf"; mkdir -p "/data/bigval-$c-cf"
    "$BIN/mysqld" --no-defaults --initialize-insecure --user=root \
        --basedir="$BASE" --datadir="/data/bigval-$c" > "$OUTDIR/logs/init-$c.log" 2>&1
    start_server "$c"
    sqlq "drop database if exists $DB; create database $DB" >/dev/null

    t0=$(date +%s)
    sb "$c" --threads=8 prepare > "$OUTDIR/logs/prepare-$c.log" 2>&1 || die "prepare failed for $c"
    secs=$(( $(date +%s) - t0 ))
    bytes=$(space_of "$c")
    echo "$c,$secs,$bytes,$logical" >> "$OUTDIR/space.csv"
    log "  loaded in ${secs}s, $(numfmt --to=iec "$bytes") on disk for $(numfmt --to=iec $logical) of payload"

    # pull the dataset in before timing
    for i in $(seq 1 "$TABLES"); do sqlq "select count(*), sum(k) from $DB.bigval$i" >/dev/null; done

    for mode in select insert; do
        for n in $THREADS; do
            tag="$c-$mode-${n}t"
            sb "$c" --mode="$mode" --threads="$n" --time="$WARMUP" run >/dev/null 2>&1
            sb "$c" --mode="$mode" --threads="$n" --time="$DURATION" --report-interval=1 run \
                > "$OUTDIR/raw/$tag.out" 2>&1
            tps=$(awk '/^ *transactions:/{gsub(/[()]/,"",$3); print $3; exit}' "$OUTDIR/raw/$tag.out")
            p95=$(awk '/95th percentile:/{print $3; exit}' "$OUTDIR/raw/$tag.out")
            echo "$c,$mode,$n,${tps:-},${p95:-}" >> "$OUTDIR/results.csv"
            log "  $tag  tps=${tps:-?}  p95=${p95:-?}ms"
        done
    done
    stop_server
done
log "done; results in $OUTDIR"
