#!/usr/bin/env bash
# Launch-article benchmark: TideSQL-MySQL v2.0.0 against InnoDB on MySQL 26.7.0.
#
# Deliberately small and fast.  This is not the TPROC-C analysis -- it answers
# what a launch article should answer, in about an hour:
#
#   point_select   is a point lookup competitive with InnoDB?
#   update_index   an indexed update, where an LSM should do well
#   read_write     the mixed read/write workload
#   write_only     sustained write throughput
#   writeamp       bytes written to the device per operation, from /proc/diskstats
#   delete         deletes, on a freshly reloaded dataset
#   space          load time and bytes on disk, with TidesDB compressing by
#                  default (LZ4) and InnoDB not
#
# The dataset is deliberately larger than the cache each engine is given, under a
# cgroup cap so the OS page cache cannot quietly hold the rest.  That is the
# condition where a B+tree and an LSM actually differ.
set -u

BASE=/data/mysql
BIN=$BASE/bin
HERE=$(cd "$(dirname "$0")" && pwd)
SB=${SB:-$(command -v sysbench)}
LUA=${LUA:-/root/sqlanalysis/sysbench/lua}

ENGINES=${ENGINES:-tidesdb innodb}
# ONLY=delete re-runs just that workload, for when one needs redoing and the
# rest are already measured.  Empty means run them all.
ONLY=${ONLY:-}
want() { [ -z "$ONLY" ] || [ "$ONLY" = "$1" ]; }
# note: `want x && for ...` simply skips the loop when x is not wanted
# 24 threads is the core count; the earlier runs peaked at 32.  Two points
# bracket the peak without quadrupling the runtime.
THREADS=${THREADS:-24 32}
TABLES=${TABLES:-8}
ROWS=${ROWS:-5000000}
# 30s was not enough.  In the earlier sysbench analysis TidesDB settled inside a
# 30s window (-0.2% to +1.2% across it) but InnoDB did not: write_only fell 14.5%,
# update_non_index 12.8%, delete 10.6%, and update_index was still climbing +56%
# as its buffer pool warmed.  A window that catches one engine mid-transient, in
# both directions, is worse than a consistently biased one.
DURATION=${DURATION:-120}
WARMUP=${WARMUP:-60}
# The dataset is ~8 GB and each engine gets 2 GB, so about a quarter of it is
# cacheable.  A fully cached dataset flatters both engines and removes InnoDB's
# main cost -- a random write to a resident page is cheap -- so it answers a
# question nobody has.  This asks what each engine does when memory is scarce.
# Both engines run on their own defaults.  Nothing here sizes a cache, a buffer
# pool or a memtable, so neither engine is tuned into a better position than the
# other.  Only two things are changed from stock, and both are for comparability
# rather than speed: the isolation level and the durability mode.
# This host has 125 GB of RAM, so without a cap the OS page cache holds the whole
# dataset whatever the engine is given and "2 GB of cache" means nothing.  The
# cap bounds engine memory and page cache together.
MEMMAX=${MEMMAX:-4G}
# Seconds to keep counting device writes after the window closes.  TidesDB with
# memtable_sync_mode=NONE and a multi-GB memtable can finish a short run having
# written almost nothing to the device; those writes still have to happen, so
# without this its write amplification reads as near zero against InnoDB's.
SETTLE=${SETTLE:-30}
# device backing /data, for the write amplification counters
DEV=${DEV:-$(findmnt -no SOURCE --target /data | sed 's|/dev/||')}
OUTDIR=${OUTDIR:-$HERE/run}

SOCK=/tmp/launch-mysql.sock
DB=sbtest
CUR_ENGINE=

die() { echo "FATAL: $*" | tee -a "${OUTDIR:-/tmp}/bench.log" >&2; exit 1; }
log() { echo "$(date -Is) $*" | tee -a "$OUTDIR/bench.log"; }

datadir_for() { echo "/data/launch-$1"; }
cfdir_for()   { echo "/data/launch-$1-cf"; }

srv_up() { pgrep -x mysqld >/dev/null; }

stop_server() {
    srv_up || return 0
    "$BIN/mysqladmin" --socket="$SOCK" -u root shutdown >/dev/null 2>&1
    for _ in $(seq 60); do srv_up || return 0; sleep 1; done
    kill -9 $(pgrep -x mysqld) 2>/dev/null; sleep 2
}

cleanup() { stop_server; }
trap cleanup EXIT INT TERM

start_server() {   # engine [extra args...]
    local e=$1; shift
    local dd cf extra=()
    dd=$(datadir_for "$e"); cf=$(cfdir_for "$e")
    # Only two departures from stock, both for comparability rather than speed:
    # the durability mode, matched across the engines, and the isolation level
    # set below.  The data home dir and the log level are operational: unset, the
    # plugin puts its column families in a sibling of the datadir that every
    # datadir in that parent shares, and it logs at TRACE into a file.
    if [ "$e" = tidesdb ]; then
        extra+=(--plugin-load-add=ha_tidesdb.so --default-storage-engine=TidesDB
                --tidesdb-data-home-dir="$cf"
                --tidesdb-log-level=NONE --tidesdb-log-to-file=OFF
                --tidesdb-memtable-sync-mode=NONE)
    else
        extra+=(--default-storage-engine=InnoDB
                --innodb-flush-log-at-trx-commit=0)
    fi
    # jemalloc for the whole process, matching how the MariaDB runs were done;
    # the installer's --allocator only covers libtidesdb's own allocations
    LD_LIBRARY_PATH=/usr/local/lib LD_PRELOAD=/lib/x86_64-linux-gnu/libjemalloc.so.2 \
    "$BIN/mysqld" --no-defaults --user=root --basedir="$BASE" --datadir="$dd" \
        --socket="$SOCK" --skip-networking --skip-log-bin --performance-schema=OFF \
        --transaction-isolation=READ-COMMITTED \
        --log-error="$dd/err.log" --plugin-dir="$BASE/lib/plugin" \
        "${extra[@]}" "$@" >>"$OUTDIR/logs/server-$e.out" 2>&1 &
    for _ in $(seq 180); do
        "$BIN/mysql" --socket="$SOCK" -u root -e "select 1" >/dev/null 2>&1 && return 0
        sleep 1
    done
    tail -25 "$dd/err.log" 2>/dev/null
    die "$e server did not start"
}

sql() { "$BIN/mysql" --socket="$SOCK" -u root -e "$1"; }

# Bytes written to the device, from the kernel rather than from either engine's
# own accounting, so both are measured the same way below the engine.
# /proc/diskstats field 10 is sectors written, 512 bytes each.
dev_written() { awk -v d="$DEV" '$3==d {print $10 * 512; exit}' /proc/diskstats; }
sqlq() { "$BIN/mysql" --socket="$SOCK" -u root -N -B -e "$1" 2>/dev/null; }

init_datadir() {   # engine
    local dd; dd=$(datadir_for "$1")
    rm -rf "$dd" "$(cfdir_for "$1")"; mkdir -p "$(cfdir_for "$1")"
    "$BIN/mysqld" --no-defaults --initialize-insecure --user=root \
        --basedir="$BASE" --datadir="$dd" > "$OUTDIR/logs/init-$1.log" 2>&1
}

verify_engine() {  # engine -- never measure the wrong engine
    local want got
    case $1 in tidesdb) want=TidesDB ;; innodb) want=InnoDB ;; esac
    got=$(sqlq "select engine from information_schema.tables
                where table_schema='$DB' and table_name='sbtest1'")
    [ "$got" = "$want" ] || die "sbtest1 is $got, expected $want"
}

space_of() {  # engine -> bytes actually occupied by the data
    local dd cf total pre
    dd=$(datadir_for "$1"); cf=$(cfdir_for "$1")
    total=$(du -sb "$dd" "$cf" 2>/dev/null | awk '{s+=$1} END{print s+0}')
    # InnoDB writes its redo capacity out full and empty; it is not data
    pre=$(find "$dd" -path '*#innodb_redo*' -o -name 'ib_logfile*' -o -name 'undo_*' 2>/dev/null \
          | xargs -r stat -c %s 2>/dev/null | awk '{s+=$1} END{print s+0}')
    echo "$(( total - pre ))"
}

warm_cache() {  # engine
    # Sized to fit in cache is not the same as resident.  A random point lookup
    # only caches the rows it touches, so at ~200k lookups/s warming 9 GB takes
    # minutes -- a short warmup would leave most reads hitting the device while
    # the figure claimed to measure the engine's code path.  Scan every table
    # once to pull the dataset in.
    local t0 i
    t0=$(date +%s)
    for i in $(seq 1 "$TABLES"); do
        sqlq "select count(*), sum(k), sum(length(c)) from $DB.sbtest$i" >/dev/null 2>&1
    done
    log "  cache warmed by full scan in $(( $(date +%s) - t0 ))s"
}

sb() {  # lua-script args...
    local script=$1; shift
    LUA_PATH="$LUA/?.lua;;" "$SB" "$LUA/$script.lua" \
        --db-driver=mysql --mysql-socket="$SOCK" --mysql-user=root \
        --mysql-db="$DB" --tables="$TABLES" --table-size="$ROWS" \
        --rand-type=uniform --auto-inc=on \
        `# 1180 is TidesDB's commit-time write conflict under optimistic MVCC;` \
        `# 1205/1213 are InnoDB lock wait and deadlock.  Counted for both, fatal` \
        `# for neither, so one conflict does not end a run.` \
        --mysql-ignore-errors=1180,1205,1213 \
        --mysql-storage-engine="${CUR_ENGINE:?}" "$@"
}

# Sets LOAD_SECONDS rather than echoing it.  Returning the timing through a
# command substitution meant start_server ran inside a subshell, which is both
# harder to reason about and left the caller waiting on a pipe it did not own.
LOAD_SECONDS=0
load_dataset() {   # engine -- leaves the server running, sets LOAD_SECONDS
    local e=$1 t0
    CUR_ENGINE=$e
    init_datadir "$e"
    start_server "$e"
    sql "drop database if exists $DB; create database $DB"
    t0=$(date +%s)
    sb oltp_read_write --threads=16 prepare > "$OUTDIR/logs/prepare-$e.log" 2>&1 \
        || die "prepare failed for $e"
    LOAD_SECONDS=$(( $(date +%s) - t0 ))
}

# A run against a server that is not there yields an empty row rather than an
# error, so check instead of discovering it in the results.
require_server() {
    srv_up || die "server not running ($1) -- see /data/launch-${CUR_ENGINE:-?}/err.log"
    "$BIN/mysql" --socket="$SOCK" -u root -e "select 1" >/dev/null 2>&1 \
        || die "server not answering ($1)"
}

one_run() {  # engine workload script threads
    local e=$1 w=$2 script=$3 n=$4 tag out tps p95 rc events wbefore wafter wrote perop
    require_server "before $e/$w/${n}t"
    tag="$e-$w-${n}t"
    out="$OUTDIR/raw/$tag.out"
    [ "$WARMUP" -gt 0 ] && sb "$script" --threads="$n" --time="$WARMUP" run >/dev/null 2>&1

    wbefore=$(dev_written)
    sb "$script" --threads="$n" --time="$DURATION" --report-interval=1 run > "$out" 2>&1
    rc=$?
    # let deferred writes land before closing the counter, or an engine that
    # defers them is credited with work it has not done yet
    sync; for _ in $(seq "$SETTLE"); do sleep 1; done
    wafter=$(dev_written)
    wrote=$(( wafter - wbefore ))

    tps=$(awk '/^ *transactions:/{gsub(/[()]/,"",$3); print $3; exit}' "$out")
    p95=$(awk '/95th percentile:/{print $3; exit}' "$out")
    events=$(awk '/total number of events:/{print $5; exit}' "$out")
    perop=""
    [ -n "${events:-}" ] && [ "${events:-0}" -gt 0 ] && perop=$(( wrote / events ))
    echo "$e,$w,$n,${tps:-},${p95:-},${events:-},${wrote},${perop},$rc" >> "$OUTDIR/results.csv"
    log "  $tag  tps=${tps:-?}  p95=${p95:-?}ms  wrote=$(numfmt --to=iec "$wrote")  ${perop:-?} B/op"
}

# ---------------------------------------------------------------------------
mkdir -p "$OUTDIR/logs" "$OUTDIR/raw"
: > "$OUTDIR/bench.log"
echo "engine,workload,threads,tps,p95_ms,events,dev_write_bytes,write_bytes_per_op,rc" > "$OUTDIR/results.csv"
echo "engine,stage,seconds,bytes" > "$OUTDIR/space.csv"

[ -x "$SB" ] || die "no sysbench on PATH"
[ -x "$BIN/mysqld" ] || die "no mysqld at $BIN/mysqld"
srv_up && die "a mysqld is already running"

cat > "$OUTDIR/run.json" <<EOF
{
 "server": "$("$BIN/mysqld" --version 2>/dev/null | sed 's/.*Ver //;s/ for .*//')",
 "sysbench": "$("$SB" --version)",
 "engines": "$ENGINES",
 "threads": "$THREADS",
 "tables": $TABLES,
 "rows_per_table": $ROWS,
 "duration_s": $DURATION,
 "warmup_s": $WARMUP,
 "settle_s": $SETTLE,
 "cache_per_engine": "$CACHE",
 "state": "dataset sized to fit in cache, so this measures the engine not the device",
 "host": "$(nproc) cpus, $(free -g | awk '/^Mem:/{print $2}')G ram, $(lscpu | awk -F: '/Model name/{gsub(/^ +/,"",$2); print $2; exit}')"
}
EOF

log "MySQL $("$BIN/mysqld" --version | sed 's/.*Ver //;s/ for.*//')  engine defaults, READ COMMITTED, durability matched"
log "dataset: $TABLES tables x $ROWS rows; threads: $THREADS"

for e in $ENGINES; do
    log "=== $e ==="
    load_dataset "$e"; secs=$LOAD_SECONDS
    require_server "after loading $e"
    verify_engine "$e"
    bytes=$(space_of "$e")
    echo "$e,after load,$secs,$bytes" >> "$OUTDIR/space.csv"
    log "  loaded in ${secs}s, $(numfmt --to=iec "$bytes") of data"
    warm_cache "$e"

    # Row count is unchanged by these three, so they can share a dataset.
    want point_select && for n in $THREADS; do one_run "$e" point_select oltp_point_select "$n"; done
    want read_write && for n in $THREADS; do one_run "$e" read_write   oltp_read_write   "$n"; done
    want update_index && for n in $THREADS; do one_run "$e" update_index oltp_update_index "$n"; done
    want write_only && for n in $THREADS; do one_run "$e" write_only   oltp_write_only   "$n"; done

    bytes=$(space_of "$e")
    echo "$e,after writes,0,$bytes" >> "$OUTDIR/space.csv"

    # oltp_delete removes by random id and never reinserts, so a second thread
    # count run against the same dataset would be deleting rows the first one
    # already removed.  Reload before each, not once before both.
    if want delete; then
    for n in $THREADS; do
        stop_server
        load_dataset "$e"; secs=$LOAD_SECONDS
        require_server "after reloading $e for delete at ${n}t"
        warm_cache "$e"
        one_run "$e" delete oltp_delete "$n"
    done
    fi

    bytes=$(space_of "$e")
    echo "$e,after deletes,0,$bytes" >> "$OUTDIR/space.csv"
    stop_server
done

log "done; results in $OUTDIR"
