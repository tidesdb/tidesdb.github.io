#!/usr/bin/env bash
# One number, one command, no harness.
#
#   ./minimal.sh tidesdb update_index
#   ./minimal.sh innodb  update_index
#
# Loads a dataset, runs one sysbench workload, prints throughput and the bytes
# the device actually took.  Enough to check a claim from the article without
# reading bench.sh.  bench.sh does the same thing for every workload and both
# engines, repeatably, and writes CSVs.
set -eu

ENGINE=${1:-tidesdb}            # tidesdb | innodb
WORKLOAD=${2:-update_index}     # point_select read_write update_index write_only delete
THREADS=${THREADS:-24}
TABLES=${TABLES:-8}
ROWS=${ROWS:-5000000}
TIME=${TIME:-120}

MYSQL=/data/mysql
LUA=${LUA:-/root/sqlanalysis/sysbench/lua}
DD=/data/minimal-$ENGINE
CF=/data/minimal-$ENGINE-cf
SOCK=/tmp/minimal.sock
DEV=$(findmnt -no SOURCE --target /data | sed 's|/dev/||')

case $ENGINE in
  tidesdb) EXTRA="--plugin-load-add=ha_tidesdb.so --default-storage-engine=TidesDB
                  --tidesdb-data-home-dir=$CF --tidesdb-log-level=NONE
                  --tidesdb-log-to-file=OFF --tidesdb-memtable-sync-mode=NONE" ;;
  innodb)  EXTRA="--default-storage-engine=InnoDB --innodb-flush-log-at-trx-commit=0" ;;
  *) echo "engine must be tidesdb or innodb" >&2; exit 1 ;;
esac

pgrep -x mysqld >/dev/null && { echo "a mysqld is already running" >&2; exit 1; }
rm -rf "$DD" "$CF"; mkdir -p "$CF"
$MYSQL/bin/mysqld --no-defaults --initialize-insecure --user=root \
    --basedir=$MYSQL --datadir="$DD" >/dev/null 2>&1

# Engine defaults throughout.  The only departures are the durability mode above
# and READ COMMITTED here, so an optimistic write conflict does not end the run.
LD_LIBRARY_PATH=/usr/local/lib LD_PRELOAD=/lib/x86_64-linux-gnu/libjemalloc.so.2 \
$MYSQL/bin/mysqld --no-defaults --user=root --basedir=$MYSQL --datadir="$DD" \
    --socket=$SOCK --skip-networking --skip-log-bin --performance-schema=OFF \
    --transaction-isolation=READ-COMMITTED --plugin-dir=$MYSQL/lib/plugin \
    --log-error="$DD/err.log" $EXTRA >/dev/null 2>&1 &
trap 'pkill -x mysqld 2>/dev/null || true' EXIT
for _ in $(seq 180); do $MYSQL/bin/mysql -S $SOCK -u root -e 'select 1' >/dev/null 2>&1 && break; sleep 1; done

$MYSQL/bin/mysql -S $SOCK -u root -e 'drop database if exists sbtest; create database sbtest'

sb() { LUA_PATH="$LUA/?.lua;;" sysbench "$LUA/oltp_$WORKLOAD.lua" --db-driver=mysql \
         --mysql-socket=$SOCK --mysql-user=root --mysql-db=sbtest --tables=$TABLES \
         --table-size=$ROWS --rand-type=uniform --auto-inc=on \
         --mysql-ignore-errors=1180,1205,1213 --mysql-storage-engine=$ENGINE "$@"; }

echo "loading $TABLES x $ROWS rows..."
LUA_PATH="$LUA/?.lua;;" sysbench "$LUA/oltp_read_write.lua" --db-driver=mysql \
    --mysql-socket=$SOCK --mysql-user=root --mysql-db=sbtest --tables=$TABLES \
    --table-size=$ROWS --auto-inc=on --mysql-storage-engine=$ENGINE \
    --threads=16 prepare >/dev/null

# Pull the dataset in before timing: a dataset that fits in cache is not the
# same as one that is in cache, and a random lookup only caches what it touches.
for i in $(seq 1 $TABLES); do
    $MYSQL/bin/mysql -S $SOCK -u root -NB -e "select count(*),sum(k) from sbtest.sbtest$i" >/dev/null
done

sb --threads=$THREADS --time=60 run >/dev/null 2>&1          # warmup

before=$(awk -v d=$DEV '$3==d {print $10*512; exit}' /proc/diskstats)
out=$(sb --threads=$THREADS --time=$TIME run)
# An engine that defers writes can finish having written almost nothing; wait for
# those writes so they are charged to the run that caused them.
sync; sleep 30
after=$(awk -v d=$DEV '$3==d {print $10*512; exit}' /proc/diskstats)

tps=$(awk '/^ *transactions:/{gsub(/[()]/,"",$3); print $3; exit}' <<<"$out")
events=$(awk '/total number of events:/{print $5; exit}' <<<"$out")
wrote=$(( after - before ))

echo
echo "engine        $ENGINE"
echo "workload      $WORKLOAD at $THREADS threads, ${TIME}s"
echo "throughput    $tps tps"
echo "wrote         $(numfmt --to=iec $wrote) to the device"
echo "per operation $(( wrote / events )) bytes"
