#!/usr/bin/env bash
# Figures for the launch article, one per workload, drawn with gnuplot.
#
# One figure per workload rather than a grid, so each can be attached next to the
# paragraph that discusses it.  Both engines appear on every figure, since a
# figure with one engine on it is not a comparison.
#
#   ./plot.sh [rundir]        default: ./run
#
# Writes png, svg and pdf of each figure into <rundir>/figures.
set -u

HERE=$(cd "$(dirname "$0")" && pwd)
RUN=${1:-$HERE/run}
FIG=$RUN/figures
RES=$RUN/results.csv

TIDESDB="#163AC8"
INNODB="#E17510"

die() { echo "FATAL: $*" >&2; exit 1; }
[ -f "$RES" ] || die "no $RES"
command -v gnuplot >/dev/null || die "gnuplot not installed"
mkdir -p "$FIG" "$RUN/plotdata"

label_of() { echo "$1" | tr '_' ' '; }

# caption line from run.json, so a figure always says what produced it
caption=$(python3 - "$RUN/run.json" <<'PY' 2>/dev/null || echo ""
import json,sys
try: m=json.load(open(sys.argv[1]))
except Exception: sys.exit(1)
print(f"{m.get('server','?')} · {m.get('tables','?')} tables x {int(float(m.get('rows_per_table',0))):,} rows · "
      f"{m.get('duration_s','?')}s measured after {m.get('warmup_s','?')}s warmup, {m.get('settle_s','?')}s settle")
PY
)

workloads=$(awk -F, 'NR>1 && $1!="" {print $2}' "$RES" | sort -u)
[ -n "$workloads" ] || die "no workloads in $RES"

# ---- one throughput figure per workload -----------------------------------
for w in $workloads; do
    data=$RUN/plotdata/$w.dat
    # threads  tidesdb_tps  innodb_tps
    awk -F, -v w="$w" 'NR>1 && $2==w && $4!="" {v[$3"_"$1]=$4; t[$3]=1}
        END { n=asorti(t, s, "@val_num_asc");
              for (i=1; i<=n; i++) printf "%s %s %s\n", s[i],
                   (s[i]"_tidesdb" in v ? v[s[i]"_tidesdb"] : "NaN"),
                   (s[i]"_innodb"  in v ? v[s[i]"_innodb"]  : "NaN") }' "$RES" > "$data"
    [ -s "$data" ] || continue

    gnuplot <<EOF
set terminal pngcairo size 900,560 enhanced font 'Helvetica,13'
set output '$FIG/${w}_tps.png'
set style data histograms
set style histogram clustered gap 2
set style fill solid 1.0 border -1
set boxwidth 0.9
set grid ytics lc rgb '#cccccc' lw 1
set border 3
set xtics nomirror
set ytics nomirror
set key top left reverse Left samplen 1.5
set title "$(label_of "$w")  —  transactions per second" font 'Helvetica,15'
set xlabel 'threads'
set ylabel 'transactions / second'
set yrange [0:*]
set label 1 "$caption" at screen 0.5, 0.025 center font 'Helvetica,9' tc rgb '#666666'
set bmargin 5
plot '$data' using 2:xtic(1) title 'TidesDB' lc rgb '$TIDESDB', \
     ''      using 3         title 'InnoDB'  lc rgb '$INNODB'
EOF
    for term in svg pdfcairo; do
        ext=svg; [ "$term" = pdfcairo ] && ext=pdf
        gnuplot <<EOF 2>/dev/null
set terminal $term size 900,560 $( [ "$term" = pdfcairo ] && echo "" || echo "enhanced" ) font 'Helvetica,13'
set output '$FIG/${w}_tps.$ext'
set style data histograms
set style histogram clustered gap 2
set style fill solid 1.0 border -1
set boxwidth 0.9
set grid ytics lc rgb '#cccccc'
set border 3
set xtics nomirror
set ytics nomirror
set key top left reverse Left samplen 1.5
set title "$(label_of "$w")  —  transactions per second"
set xlabel 'threads'
set ylabel 'transactions / second'
set yrange [0:*]
plot '$data' using 2:xtic(1) title 'TidesDB' lc rgb '$TIDESDB', \
     ''      using 3         title 'InnoDB'  lc rgb '$INNODB'
EOF
    done
    echo "  figures/${w}_tps.{png,svg,pdf}"
done

# ---- one write-amplification figure, workloads that actually write --------
wdata=$RUN/plotdata/write_bytes.dat
awk -F, 'NR>1 && $8!="" && $8+0 > 0 {
            key=$2; v[key"_"$1]=($8>v[key"_"$1]?v[key"_"$1]:v[key"_"$1]); s[key"_"$1]+=$8; c[key"_"$1]++; w[key]=1 }
         END { n=asorti(w, ws);
               for (i=1; i<=n; i++) {
                 k=ws[i]
                 td=(k"_tidesdb" in c ? s[k"_tidesdb"]/c[k"_tidesdb"] : "NaN")
                 ib=(k"_innodb"  in c ? s[k"_innodb"]/c[k"_innodb"]   : "NaN")
                 if (td!="NaN" && ib!="NaN" && (td>0 || ib>0))
                     printf "%s %.0f %.0f\n", k, td, ib
               } }' "$RES" > "$wdata"

if [ -s "$wdata" ]; then
    gnuplot <<EOF
set terminal pngcairo size 900,520 enhanced font 'Helvetica,13'
set output '$FIG/write_bytes_per_op.png'
set style data histograms
set style histogram clustered gap 2
set style fill solid 1.0 border -1
set boxwidth 0.9
set grid ytics lc rgb '#cccccc'
set border 3
set xtics nomirror rotate by -20
set ytics nomirror
set logscale y
set key top left reverse Left samplen 1.5
set title 'Bytes written to the device per operation (log scale)' font 'Helvetica,15'
set ylabel 'bytes / operation'
set label 1 "$caption" at screen 0.5, 0.02 center font 'Helvetica,9' tc rgb '#666666'
set bmargin 6
plot '$wdata' using 2:xtic(1) title 'TidesDB' lc rgb '$TIDESDB', \
     ''       using 3         title 'InnoDB'  lc rgb '$INNODB'
EOF
    echo "  figures/write_bytes_per_op.png"
fi

echo "  done -> $FIG"
