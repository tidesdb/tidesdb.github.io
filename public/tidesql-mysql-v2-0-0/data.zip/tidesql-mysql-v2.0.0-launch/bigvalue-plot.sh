#!/usr/bin/env bash
# Two figures for the large-value run: peak throughput, and bytes on disk for
# the same dataset.
#
#   ./bigvalue-plot.sh [rundir]        default: ./bigvalue-run
set -u

HERE=$(cd "$(dirname "$0")" && pwd)
RUN=${1:-$HERE/bigvalue-run}
RES=$RUN/results.csv
SPC=$RUN/space.csv
FIG=$RUN/figures

[ -f "$RES" ] || { echo "no $RES" >&2; exit 1; }
mkdir -p "$FIG" "$RUN/plotdata"

TIDESDB="#163AC8"
INLINE="#7D93E4"
INNODB="#E17510"

# ---- peak throughput by mode ----------------------------------------------
# Peak across thread counts rather than a sweep: 16 cores, so 24 and 32 threads
# are both oversubscribed and the sweep says nothing the peak does not.
data=$RUN/plotdata/bigvalue_tps.dat
awk -F, 'NR>1 && $4!="" { k=$2"_"$1; if ($4+0 > v[k]) v[k]=$4+0; m[$2]=1 }
    END { n=asorti(m, ms)
          for (i=1; i<=n; i++) { k=ms[i]
            printf "%s %s %s %s\n", k,
              (k"_tidesdb"        in v ? v[k"_tidesdb"]        : "NaN"),
              (k"_tidesdb-inline" in v ? v[k"_tidesdb-inline"] : "NaN"),
              (k"_innodb"         in v ? v[k"_innodb"]         : "NaN") } }' "$RES" > "$data"
[ -s "$data" ] || { echo "no rows in $RES" >&2; exit 1; }

gnuplot <<EOF
set terminal pngcairo size 900,540 enhanced font 'Helvetica,13'
set output '$FIG/bigvalue_tps.png'
set style data histograms
set style histogram clustered gap 2
set style fill solid 1.0 border -1
set boxwidth 0.9
set grid ytics lc rgb '#cccccc'
set border 3
set xtics nomirror
set ytics nomirror
set key top right reverse Left samplen 1.5
set title '4 KB values — peak transactions per second' font 'Helvetica,15'
set ylabel 'transactions / second'
set yrange [0:*]
set label 1 '4 tables x 200,000 rows x 4096 B payload, uniform keys, engine defaults' \
    at screen 0.5, 0.025 center font 'Helvetica,9' tc rgb '#666666'
set bmargin 5
plot '$data' using 2:xtic(1) title 'TidesDB'        lc rgb '$TIDESDB', \
     ''      using 3         title 'TidesDB inline' lc rgb '$INLINE', \
     ''      using 4         title 'InnoDB'         lc rgb '$INNODB'
EOF
echo "  figures/bigvalue_tps.png"

# ---- bytes on disk for the same dataset -----------------------------------
if [ -f "$SPC" ]; then
    sdata=$RUN/plotdata/bigvalue_space.dat
    awk -F, 'NR>1 && $3!="" {
                lbl=($1=="tidesdb-inline" ? "TidesDB inline" : ($1=="tidesdb" ? "TidesDB" : "InnoDB"))
                col=($1=="tidesdb" ? 1456328 : ($1=="tidesdb-inline" ? 8229348 : 14775056))
                printf "%d \"%s\" %.3f %d\n", NR-2, lbl, $3/1073741824, col }' "$SPC" > "$sdata"
    logical=$(awk -F, 'NR==2{printf "%.2f", $4/1073741824}' "$SPC")

    gnuplot <<EOF
set terminal pngcairo size 760,480 enhanced font 'Helvetica,13'
set output '$FIG/bigvalue_space.png'
set boxwidth 0.5
set grid ytics lc rgb '#cccccc'
set border 3
unset xtics
set ytics nomirror
unset key
set title 'Same dataset, bytes on disk after load' font 'Helvetica,15'
set ylabel 'GiB on disk'
set yrange [0:*]
set arrow 1 from graph 0, first $logical to graph 1, first $logical nohead \
    lc rgb '#999999' dt 2 lw 2
set label 2 "$logical GiB of payload" at graph 0.62, first $logical offset 0,0.8 \
    font 'Helvetica,10' tc rgb '#666666'
set label 1 'LZ4 is the TidesDB default; InnoDB uncompressed, its default' \
    at screen 0.5, 0.03 center font 'Helvetica,9' tc rgb '#666666'
set bmargin 5
set style fill solid 1.0 border -1
set xrange [-0.6:2.6]
plot '$sdata' using 1:3:(0.5):4 with boxes lc rgb variable notitle, \
     '' using 1:3:(sprintf("%.2f", \$3)) with labels offset 0,0.8 \
        font 'Helvetica,11' tc rgb '#333333' notitle, \
     '' using 1:(0):2 with labels offset 0,-1.2 font 'Helvetica,11' \
        tc rgb '#333333' notitle
EOF
    echo "  figures/bigvalue_space.png"
fi
