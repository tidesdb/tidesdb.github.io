-- bigvalue.lua -- large-value workload for sysbench.
--
-- sysbench's own sbtest row is about 188 bytes, which sits below TidesDB's
-- value separation threshold (1024 by default), so a standard sysbench run
-- never puts anything in the shared value log.  This script exists to cross
-- that line on purpose: the value column is sized by --value_size, so the same
-- script measures the inline path and the value-log path by changing one number.
--
--   prepare:  sysbench bigvalue.lua --value_size=4096 ... prepare
--   run:      sysbench bigvalue.lua --value_size=4096 --mode=select ... run
--   cleanup:  sysbench bigvalue.lua ... cleanup
--
-- Self-contained on purpose, so it can be published alongside the numbers and
-- re-run without the rest of a sysbench tree.

sysbench.cmdline.options = {
   tables       = {"Number of tables", 4},
   table_size   = {"Rows per table", 200000},
   value_size   = {"Bytes in the value column", 4096},
   mode         = {"Workload: select, insert or update", "select"},
   engine       = {"Storage engine for CREATE TABLE", "innodb"},
   create_opts  = {"Extra text appended to CREATE TABLE (e.g. ENGINE_ATTRIBUTE=...)", ""},
}

-- One payload per thread, built once.  Generating it per event would measure
-- Lua string building rather than the engine.
local payload

-- Payload entropy decides what a compression number means.  Pure repetition
-- compresses to almost nothing and flatters any engine that compresses; random
-- bytes compress not at all and flatter any engine that does not.  Neither is
-- real data.  This builds text from a small vocabulary, which is roughly how
-- documents, logs and JSON behave and compresses around 2-3x.
local WORDS = {
   "order","customer","invoice","shipment","address","payment","status","created",
   "updated","region","quantity","price","currency","discount","category","vendor",
   "warehouse","tracking","carrier","priority","comment","reference","batch","item",
}
local function build_payload(n)
   local t, len = {}, 0
   local rng = 0
   while len < n do
      -- a cheap deterministic walk over the vocabulary, so every thread builds
      -- the same bytes and the payload is not re-randomised per call
      rng = (rng * 1103515245 + 12345) % 2147483648
      local w = WORDS[(rng % #WORDS) + 1]
      t[#t + 1] = w
      len = len + #w + 1
   end
   return string.sub(table.concat(t, " "), 1, n)
end

local function create_table(drv, con, num)
   local opts = sysbench.opt.create_opts
   if opts ~= "" then opts = " " .. opts end
   con:query(string.format([[
CREATE TABLE IF NOT EXISTS bigval%d (
  id BIGINT NOT NULL AUTO_INCREMENT,
  k  INT NOT NULL DEFAULT 0,
  v  LONGBLOB NOT NULL,
  PRIMARY KEY (id),
  KEY k_%d (k)
) ENGINE=%s%s]], num, num, sysbench.opt.engine, opts))

   if sysbench.opt.table_size <= 0 then return end

   print(string.format("Inserting %d rows of %d bytes into bigval%d...",
                       sysbench.opt.table_size, sysbench.opt.value_size, num))

   local val = build_payload(sysbench.opt.value_size)
   -- batched so the load is not one round trip per row
   local batch = math.max(1, math.floor(262144 / sysbench.opt.value_size))
   local i = 1
   while i <= sysbench.opt.table_size do
      local last = math.min(i + batch - 1, sysbench.opt.table_size)
      local rows = {}
      for _ = i, last do
         rows[#rows + 1] = string.format("(%d,'%s')", sysbench.rand.default(1, 1000000), val)
      end
      con:bulk_insert_init(string.format("INSERT INTO bigval%d (k, v) VALUES", num))
      con:bulk_insert_next(table.concat(rows, ","))
      con:bulk_insert_done()
      i = last + 1
   end
end

function cmd_prepare()
   local drv = sysbench.sql.driver()
   local con = drv:connect()
   for i = sysbench.tid % sysbench.opt.threads + 1, sysbench.opt.tables,
           sysbench.opt.threads do
      create_table(drv, con, i)
   end
end

function cmd_cleanup()
   local drv = sysbench.sql.driver()
   local con = drv:connect()
   for i = 1, sysbench.opt.tables do
      print(string.format("Dropping bigval%d...", i))
      con:query(string.format("DROP TABLE IF EXISTS bigval%d", i))
   end
end

sysbench.cmdline.commands = {
   prepare = {cmd_prepare, sysbench.cmdline.PARALLEL_COMMAND},
   cleanup = {cmd_cleanup, sysbench.cmdline.SEQUENTIAL_COMMAND},
}

function thread_init()
   drv = sysbench.sql.driver()
   con = drv:connect()
   payload = build_payload(sysbench.opt.value_size)
end

function thread_done()
   con:disconnect()
end

function event()
   local t  = sysbench.rand.uniform(1, sysbench.opt.tables)
   local id = sysbench.rand.default(1, sysbench.opt.table_size)
   local m  = sysbench.opt.mode

   if m == "select" then
      con:query(string.format("SELECT v FROM bigval%d WHERE id = %d", t, id))
   elseif m == "insert" then
      con:query(string.format("INSERT INTO bigval%d (k, v) VALUES (%d, '%s')",
                              t, sysbench.rand.default(1, 1000000), payload))
   elseif m == "update" then
      con:query(string.format("UPDATE bigval%d SET v = '%s' WHERE id = %d",
                              t, payload, id))
   else
      error("unknown --mode: " .. tostring(m) .. " (select, insert or update)")
   end
end
