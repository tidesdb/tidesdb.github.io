set tmpdir $::env(TMP)
set ::outputfile $tmpdir/maria_tprocc
source /home/agpmastersystem/HammerDB-5.0/scripts/tcl/generic/generic_tprocc_result.tcl
